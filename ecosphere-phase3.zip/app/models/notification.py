from datetime import datetime
from app.extensions import db
from app.models.base import BaseModel

NOTIFICATION_TYPES = [
    "carbon_approved", "carbon_rejected", "csr_reminder",
    "compliance_assigned", "audit_assigned", "badge_earned",
    "challenge_completed", "challenge_invite", "general",
]


class Notification(BaseModel):
    """An in-app notification for a single user."""

    __tablename__ = "notifications"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    notif_type = db.Column(db.String(40), nullable=False, default="general", index=True)
    title = db.Column(db.String(150), nullable=False)
    body = db.Column(db.String(500))
    link = db.Column(db.String(255))  # relative URL to route to on click
    icon = db.Column(db.String(60), default="bi-bell")

    is_read = db.Column(db.Boolean, default=False, nullable=False, index=True)
    read_at = db.Column(db.DateTime, nullable=True)

    user = db.relationship("User", foreign_keys=[user_id])

    def mark_read(self):
        if not self.is_read:
            self.is_read = True
            self.read_at = datetime.utcnow()

    def __repr__(self):
        return f"<Notification user={self.user_id} type={self.notif_type} read={self.is_read}>"
