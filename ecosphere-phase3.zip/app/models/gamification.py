from datetime import datetime
from app.extensions import db
from app.models.base import BaseModel

BADGE_CRITERIA_TYPES = [
    "xp_total", "carbon_logged_count", "csr_hours_total",
    "csr_participation_count", "audit_completed_count",
    "compliance_resolved_count", "challenge_completed_count",
]

CHALLENGE_STATUSES = ["draft", "active", "completed", "cancelled"]
CHALLENGE_METRICS = [
    "carbon_logged_count", "csr_hours_total", "csr_participation_count",
    "compliance_resolved_count", "xp_earned",
]


class XPTransaction(BaseModel):
    """
    Immutable ledger of every XP/coin award. User.xp_points/coins are a
    denormalized running total kept in sync whenever a row is inserted here,
    so dashboards can read the cheap total while this table remains the
    source of truth / audit trail for *why* a user has the XP they have.
    """

    __tablename__ = "xp_transactions"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    amount = db.Column(db.Integer, nullable=False)  # XP awarded (can be negative for corrections)
    coins = db.Column(db.Integer, nullable=False, default=0)
    reason_code = db.Column(db.String(60), nullable=False, index=True)  # e.g. "carbon.approved"
    description = db.Column(db.String(255))

    entity_type = db.Column(db.String(80))
    entity_id = db.Column(db.Integer)

    user = db.relationship("User", foreign_keys=[user_id])

    def __repr__(self):
        return f"<XPTransaction user={self.user_id} amount={self.amount} ({self.reason_code})>"


class Badge(BaseModel):
    """A definition of an unlockable badge and the criteria that unlocks it."""

    __tablename__ = "badges"

    code = db.Column(db.String(60), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.String(255))
    icon = db.Column(db.String(60), nullable=False, default="bi-award")  # bootstrap-icons class
    criteria_type = db.Column(db.String(40), nullable=False)  # one of BADGE_CRITERIA_TYPES
    criteria_threshold = db.Column(db.Integer, nullable=False)
    xp_reward = db.Column(db.Integer, nullable=False, default=0)
    is_active = db.Column(db.Boolean, default=True, nullable=False)

    def __repr__(self):
        return f"<Badge {self.code}>"


class UserBadge(BaseModel):
    """A badge a user has earned. One row per user/badge pair."""

    __tablename__ = "user_badges"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    badge_id = db.Column(db.Integer, db.ForeignKey("badges.id"), nullable=False, index=True)
    earned_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", foreign_keys=[user_id])
    badge = db.relationship("Badge", foreign_keys=[badge_id])

    __table_args__ = (
        db.UniqueConstraint("user_id", "badge_id", name="uq_user_badge"),
    )

    def __repr__(self):
        return f"<UserBadge user={self.user_id} badge={self.badge_id}>"


class Challenge(BaseModel):
    """
    A time-boxed team/org goal (e.g. "Log 500kg less CO2e this month").
    Progress is measured against `metric` scoped to the org, optionally to a
    single department, over [starts_on, ends_on].
    """

    __tablename__ = "challenges"

    organization_id = db.Column(
        db.Integer, db.ForeignKey("organizations.id"), nullable=False, index=True
    )
    department_id = db.Column(db.Integer, db.ForeignKey("departments.id"), nullable=True, index=True)
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    metric = db.Column(db.String(40), nullable=False)  # one of CHALLENGE_METRICS
    target_value = db.Column(db.Integer, nullable=False)
    xp_reward = db.Column(db.Integer, nullable=False, default=50)
    starts_on = db.Column(db.Date, nullable=False)
    ends_on = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="draft", index=True)

    department = db.relationship("Department", foreign_keys=[department_id])
    created_by = db.relationship("User", foreign_keys=[created_by_id])
    participants = db.relationship(
        "ChallengeParticipant", backref="challenge", lazy="dynamic",
        cascade="all, delete-orphan",
    )

    @property
    def participant_count(self):
        return self.participants.filter_by(is_deleted=False).count()

    @property
    def is_open(self):
        today = datetime.utcnow().date()
        return self.status == "active" and self.starts_on <= today <= self.ends_on

    def __repr__(self):
        return f"<Challenge {self.title} ({self.status})>"


class ChallengeParticipant(BaseModel):
    """An employee's enrollment + progress in a Challenge."""

    __tablename__ = "challenge_participants"

    challenge_id = db.Column(db.Integer, db.ForeignKey("challenges.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    progress_value = db.Column(db.Integer, nullable=False, default=0)
    completed_at = db.Column(db.DateTime, nullable=True)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", foreign_keys=[user_id])

    __table_args__ = (
        db.UniqueConstraint("challenge_id", "user_id", name="uq_challenge_participant"),
    )

    @property
    def is_completed(self):
        return self.completed_at is not None

    def __repr__(self):
        return f"<ChallengeParticipant user={self.user_id} challenge={self.challenge_id}>"
