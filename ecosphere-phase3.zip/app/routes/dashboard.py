from flask import Blueprint, render_template
from flask_login import login_required, current_user

from app.models.organization import Organization
from app.utils import dashboard_data as dd

dashboard_bp = Blueprint("dashboard", __name__, template_folder="../templates/dashboard")


# Role -> dashboard template mapping. Each role sees a different landing
# view; data widgets are computed per role in index() below since each
# role needs a different scope (org-wide vs department vs personal).
ROLE_TEMPLATES = {
    "super_admin": "dashboard/super_admin.html",
    "org_admin": "dashboard/org_admin.html",
    "department_manager": "dashboard/manager.html",
    "employee": "dashboard/employee.html",
    "auditor": "dashboard/auditor.html",
    "csr_manager": "dashboard/csr_manager.html",
    "viewer": "dashboard/viewer.html",
}


@dashboard_bp.route("/")
@login_required
def index():
    role_name = current_user.role.name if current_user.role else "viewer"
    template = ROLE_TEMPLATES.get(role_name, "dashboard/viewer.html")
    org_id = current_user.organization_id
    dept_id = current_user.department_id

    context = {"role_name": role_name}

    if role_name == "super_admin":
        context["platform_org_count"] = Organization.query.filter_by(
            is_deleted=False, is_active=True
        ).count()
        from app.models.user import User
        context["platform_user_count"] = User.query.filter_by(is_deleted=False, is_active=True).count()
        scores = dd.esg_composite_scores(None)
        context["scores"] = scores
        context["carbon_trend"] = dd.carbon_trend(None)
        context["audit_compliance"] = dd.audit_compliance_stats(None)
        context["kpis"] = dd.kpi_summary(None)
        context["leaderboard"] = dd.leaderboard_snippet(None)

    elif role_name == "org_admin":
        context["kpis"] = dd.kpi_summary(org_id)
        context["carbon_trend"] = dd.carbon_trend(org_id)
        context["csr_by_category"] = dd.csr_participation_by_category(org_id)
        context["audit_compliance"] = dd.audit_compliance_stats(org_id)
        context["leaderboard"] = dd.leaderboard_snippet(org_id)

    elif role_name == "department_manager":
        context["kpis"] = dd.kpi_summary(org_id, dept_id)
        context["carbon_trend"] = dd.carbon_trend(org_id, dept_id)
        context["csr_by_category"] = dd.csr_participation_by_category(org_id, dept_id)
        context["leaderboard"] = dd.leaderboard_snippet(org_id)

    elif role_name == "employee":
        context["xp_progress"] = dd.xp_progress(current_user)
        context["kpis"] = dd.kpi_summary(org_id, dept_id)
        context["carbon_trend"] = dd.carbon_trend(org_id, dept_id)
        from app.models.gamification import UserBadge
        context["badge_count"] = UserBadge.query.filter_by(
            user_id=current_user.id, is_deleted=False
        ).count()

    elif role_name == "auditor":
        context["kpis"] = dd.kpi_summary(org_id)
        context["audit_compliance"] = dd.audit_compliance_stats(org_id)

    elif role_name == "csr_manager":
        context["kpis"] = dd.kpi_summary(org_id)
        context["csr_by_category"] = dd.csr_participation_by_category(org_id)
        context["leaderboard"] = dd.leaderboard_snippet(org_id)

    else:  # viewer
        context["scores"] = dd.esg_composite_scores(org_id)
        context["carbon_trend"] = dd.carbon_trend(org_id)
        context["csr_by_category"] = dd.csr_participation_by_category(org_id)

    return render_template(template, **context)
