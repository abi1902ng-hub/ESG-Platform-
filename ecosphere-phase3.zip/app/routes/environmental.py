from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user

from app.extensions import db
from app.models.environmental import EmissionFactor, CarbonTransaction
from app.models.organization import Department
from app.models.audit import ActivityLog
from app.utils.rbac import permission_required
from app.utils.esg_forms import EmissionFactorForm, CarbonTransactionForm, RejectTransactionForm
from app.utils.gamification_service import award_xp, update_challenge_progress, notify

environmental_bp = Blueprint(
    "environmental", __name__, template_folder="../templates/environmental"
)


def _org_scope(query, model):
    """Restrict a query to the current user's organization unless they're a super admin."""
    if current_user.organization_id:
        return query.filter(model.organization_id == current_user.organization_id)
    return query


def _log(action, entity_type, entity_id, description):
    ActivityLog.log(
        action=action, user_id=current_user.id, organization_id=current_user.organization_id,
        module="environmental", entity_type=entity_type, entity_id=entity_id,
        description=description, ip_address=request.remote_addr, user_agent=str(request.user_agent),
    )


# --- Carbon transactions ----------------------------------------------------

@environmental_bp.route("/")
@login_required
def index():
    return redirect(url_for("environmental.transactions"))


@environmental_bp.route("/transactions")
@login_required
def transactions():
    page = request.args.get("page", 1, type=int)
    status = request.args.get("status", "")

    query = CarbonTransaction.query.filter_by(is_deleted=False)
    query = _org_scope(query, CarbonTransaction)
    if not current_user.has_role("super_admin", "org_admin", "department_manager", "auditor"):
        query = query.filter_by(logged_by_id=current_user.id)
    if status:
        query = query.filter_by(status=status)

    pagination = query.order_by(CarbonTransaction.activity_date.desc()).paginate(page=page, per_page=20)

    total_co2e = sum(float(t.co2e_kg) for t in query.filter_by(status="approved").all())

    return render_template(
        "environmental/transactions.html",
        pagination=pagination, status=status, total_co2e=total_co2e,
    )


@environmental_bp.route("/transactions/new", methods=["GET", "POST"])
@login_required
@permission_required("carbon.log")
def new_transaction():
    form = CarbonTransactionForm()
    _populate_transaction_choices(form)

    if form.validate_on_submit():
        factor = db.session.get(EmissionFactor, form.emission_factor_id.data)
        if not factor:
            flash("Select a valid emission factor.", "danger")
            return render_template("environmental/transaction_form.html", form=form, is_new=True)

        txn = CarbonTransaction(
            organization_id=current_user.organization_id,
            department_id=form.department_id.data or None,
            logged_by_id=current_user.id,
            emission_factor_id=factor.id,
            activity_date=form.activity_date.data,
            quantity=form.quantity.data,
            notes=form.notes.data,
        )
        txn.compute_co2e()
        db.session.add(txn)
        db.session.flush()
        _log("carbon.create", "CarbonTransaction", txn.id, f"Logged {txn.co2e_kg}kg CO2e")
        award_xp(
            current_user, 5, "carbon.logged",
            description="Logged a carbon transaction",
            entity_type="CarbonTransaction", entity_id=txn.id,
        )
        update_challenge_progress(current_user, "carbon_logged_count", delta=1)
        db.session.commit()
        flash("Carbon transaction logged and awaiting approval.", "success")
        return redirect(url_for("environmental.transactions"))

    return render_template("environmental/transaction_form.html", form=form, is_new=True)


@environmental_bp.route("/transactions/<int:txn_id>/edit", methods=["GET", "POST"])
@login_required
@permission_required("carbon.log")
def edit_transaction(txn_id):
    txn = CarbonTransaction.query.filter_by(id=txn_id, is_deleted=False).first_or_404()
    if txn.logged_by_id != current_user.id and not current_user.has_role("super_admin", "org_admin"):
        flash("You can only edit your own transactions.", "danger")
        return redirect(url_for("environmental.transactions"))
    if txn.status != "pending":
        flash("Only pending transactions can be edited.", "warning")
        return redirect(url_for("environmental.transactions"))

    form = CarbonTransactionForm(obj=txn)
    _populate_transaction_choices(form)
    if request.method == "GET":
        form.department_id.data = txn.department_id or 0
        form.emission_factor_id.data = txn.emission_factor_id

    if form.validate_on_submit():
        factor = db.session.get(EmissionFactor, form.emission_factor_id.data)
        txn.department_id = form.department_id.data or None
        txn.emission_factor_id = factor.id
        txn.activity_date = form.activity_date.data
        txn.quantity = form.quantity.data
        txn.notes = form.notes.data
        txn.compute_co2e()
        _log("carbon.update", "CarbonTransaction", txn.id, "Updated carbon transaction")
        db.session.commit()
        flash("Transaction updated.", "success")
        return redirect(url_for("environmental.transactions"))

    return render_template("environmental/transaction_form.html", form=form, is_new=False, txn=txn)


@environmental_bp.route("/transactions/<int:txn_id>/delete", methods=["POST"])
@login_required
@permission_required("carbon.log")
def delete_transaction(txn_id):
    txn = CarbonTransaction.query.filter_by(id=txn_id, is_deleted=False).first_or_404()
    if txn.logged_by_id != current_user.id and not current_user.has_role("super_admin", "org_admin"):
        flash("You can only delete your own transactions.", "danger")
        return redirect(url_for("environmental.transactions"))
    txn.soft_delete()
    _log("carbon.delete", "CarbonTransaction", txn.id, "Deleted carbon transaction")
    db.session.commit()
    flash("Transaction deleted.", "info")
    return redirect(url_for("environmental.transactions"))


@environmental_bp.route("/transactions/<int:txn_id>/approve", methods=["POST"])
@login_required
@permission_required("carbon.approve")
def approve_transaction(txn_id):
    txn = CarbonTransaction.query.filter_by(id=txn_id, is_deleted=False).first_or_404()
    txn.approve(current_user.id)
    _log("carbon.approve", "CarbonTransaction", txn.id, "Approved carbon transaction")
    if txn.logged_by:
        award_xp(
            txn.logged_by, 10, "carbon.approved",
            description="Carbon transaction approved",
            entity_type="CarbonTransaction", entity_id=txn.id,
        )
        notify(
            txn.logged_by, "carbon_approved", "Carbon transaction approved",
            body=f"Your entry of {txn.co2e_kg}kg CO2e was approved.",
            link="/environmental/transactions", icon="bi-check-circle",
        )
    db.session.commit()
    flash("Transaction approved.", "success")
    return redirect(url_for("environmental.transactions"))


@environmental_bp.route("/transactions/<int:txn_id>/reject", methods=["POST"])
@login_required
@permission_required("carbon.approve")
def reject_transaction(txn_id):
    txn = CarbonTransaction.query.filter_by(id=txn_id, is_deleted=False).first_or_404()
    reason = request.form.get("rejection_reason", "").strip()
    txn.reject(current_user.id, reason)
    _log("carbon.reject", "CarbonTransaction", txn.id, f"Rejected: {reason}")
    if txn.logged_by:
        notify(
            txn.logged_by, "carbon_rejected", "Carbon transaction rejected",
            body=reason or "Your entry was rejected.",
            link="/environmental/transactions", icon="bi-x-circle",
        )
    db.session.commit()
    flash("Transaction rejected.", "warning")
    return redirect(url_for("environmental.transactions"))


def _populate_transaction_choices(form):
    dept_query = Department.query.filter_by(is_deleted=False)
    dept_query = _org_scope(dept_query, Department)
    form.department_id.choices = [(0, "— None —")] + [
        (d.id, d.name) for d in dept_query.order_by(Department.name).all()
    ]

    factor_query = EmissionFactor.query.filter_by(is_deleted=False, is_active=True)
    if current_user.organization_id:
        factor_query = factor_query.filter(
            (EmissionFactor.organization_id == current_user.organization_id)
            | (EmissionFactor.organization_id.is_(None))
        )
    form.emission_factor_id.choices = [
        (f.id, f"{f.name} ({f.factor_value} kgCO2e/{f.unit})")
        for f in factor_query.order_by(EmissionFactor.name).all()
    ]


# --- Emission factors (admin-managed reference data) -----------------------

@environmental_bp.route("/factors")
@login_required
@permission_required("factor.manage", "carbon.log")
def factors():
    query = EmissionFactor.query.filter_by(is_deleted=False)
    if current_user.organization_id:
        query = query.filter(
            (EmissionFactor.organization_id == current_user.organization_id)
            | (EmissionFactor.organization_id.is_(None))
        )
    items = query.order_by(EmissionFactor.scope, EmissionFactor.name).all()
    return render_template("environmental/factors.html", items=items)


@environmental_bp.route("/factors/new", methods=["GET", "POST"])
@login_required
@permission_required("factor.manage")
def new_factor():
    form = EmissionFactorForm()
    if form.validate_on_submit():
        factor = EmissionFactor(
            organization_id=current_user.organization_id,
            name=form.name.data, scope=form.scope.data, category=form.category.data,
            unit=form.unit.data, factor_value=form.factor_value.data, source=form.source.data,
        )
        db.session.add(factor)
        db.session.flush()
        _log("factor.create", "EmissionFactor", factor.id, f"Created emission factor {factor.name}")
        db.session.commit()
        flash("Emission factor created.", "success")
        return redirect(url_for("environmental.factors"))
    return render_template("environmental/factor_form.html", form=form, is_new=True)


@environmental_bp.route("/factors/<int:factor_id>/edit", methods=["GET", "POST"])
@login_required
@permission_required("factor.manage")
def edit_factor(factor_id):
    factor = EmissionFactor.query.filter_by(id=factor_id, is_deleted=False).first_or_404()
    form = EmissionFactorForm(obj=factor)
    if form.validate_on_submit():
        form.populate_obj(factor)
        _log("factor.update", "EmissionFactor", factor.id, f"Updated emission factor {factor.name}")
        db.session.commit()
        flash("Emission factor updated.", "success")
        return redirect(url_for("environmental.factors"))
    return render_template("environmental/factor_form.html", form=form, is_new=False, factor=factor)


@environmental_bp.route("/factors/<int:factor_id>/delete", methods=["POST"])
@login_required
@permission_required("factor.manage")
def delete_factor(factor_id):
    factor = EmissionFactor.query.filter_by(id=factor_id, is_deleted=False).first_or_404()
    factor.soft_delete()
    _log("factor.delete", "EmissionFactor", factor.id, f"Deleted emission factor {factor.name}")
    db.session.commit()
    flash("Emission factor deleted.", "info")
    return redirect(url_for("environmental.factors"))
