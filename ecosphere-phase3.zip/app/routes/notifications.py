from flask import Blueprint, render_template, redirect, url_for, jsonify, request
from flask_login import login_required, current_user

from app.extensions import db
from app.models.notification import Notification

notifications_bp = Blueprint(
    "notifications", __name__, template_folder="../templates/notifications"
)


@notifications_bp.route("/")
@login_required
def index():
    page = request.args.get("page", 1, type=int)
    pagination = (
        Notification.query.filter_by(user_id=current_user.id, is_deleted=False)
        .order_by(Notification.created_at.desc())
        .paginate(page=page, per_page=20)
    )
    return render_template("notifications/list.html", pagination=pagination)


@notifications_bp.route("/dropdown")
@login_required
def dropdown():
    """Lazy-loaded partial rendered inside the topbar bell dropdown."""
    items = (
        Notification.query.filter_by(user_id=current_user.id, is_deleted=False)
        .order_by(Notification.created_at.desc())
        .limit(8)
        .all()
    )
    return render_template("notifications/_dropdown.html", items=items)


@notifications_bp.route("/unread-count")
@login_required
def unread_count():
    count = Notification.query.filter_by(
        user_id=current_user.id, is_read=False, is_deleted=False
    ).count()
    return jsonify({"count": count})


@notifications_bp.route("/<int:notif_id>/read", methods=["POST"])
@login_required
def mark_read(notif_id):
    notif = Notification.query.filter_by(
        id=notif_id, user_id=current_user.id, is_deleted=False
    ).first_or_404()
    notif.mark_read()
    db.session.commit()
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": True})
    if notif.link:
        return redirect(notif.link)
    return redirect(url_for("notifications.index"))


@notifications_bp.route("/mark-all-read", methods=["POST"])
@login_required
def mark_all_read():
    unread = Notification.query.filter_by(
        user_id=current_user.id, is_read=False, is_deleted=False
    ).all()
    for n in unread:
        n.mark_read()
    db.session.commit()
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": True})
    return redirect(url_for("notifications.index"))
