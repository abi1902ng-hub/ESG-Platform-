from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user

from app.extensions import db
from app.models.social import CSRActivity, CSRParticipation
from app.models.organization import Department
from app.models.audit import ActivityLog
from app.utils.rbac import permission_required
from app.utils.esg_forms import CSRActivityForm, CSRParticipationForm
from app.utils.gamification_service import award_xp, update_challenge_progress

social_bp = Blueprint("social", __name__, template_folder="../templates/social")


def _org_scope(query, model):
    if current_user.organization_id:
        return query.filter(model.organization_id == current_user.organization_id)
    return query


def _log(action, entity_type, entity_id, description):
    ActivityLog.log(
        action=action, user_id=current_user.id, organization_id=current_user.organization_id,
        module="social", entity_type=entity_type, entity_id=entity_id,
        description=description, ip_address=request.remote_addr, user_agent=str(request.user_agent),
    )


@social_bp.route("/")
@login_required
def index():
    page = request.args.get("page", 1, type=int)
    status = request.args.get("status", "")

    query = CSRActivity.query.filter_by(is_deleted=False)
    query = _org_scope(query, CSRActivity)
    if status:
        query = query.filter_by(status=status)

    pagination = query.order_by(CSRActivity.activity_date.desc()).paginate(page=page, per_page=20)
    return render_template("social/activities.html", pagination=pagination, status=status)


@social_bp.route("/new", methods=["GET", "POST"])
@login_required
@permission_required("csr.manage")
def new_activity():
    form = CSRActivityForm()
    _populate_department_choices(form)
    if form.validate_on_submit():
        activity = CSRActivity(
            organization_id=current_user.organization_id,
            department_id=form.department_id.data or None,
            title=form.title.data, description=form.description.data,
            category=form.category.data, location=form.location.data,
            activity_date=form.activity_date.data, budget=form.budget.data or 0,
            beneficiaries_target=form.beneficiaries_target.data or 0,
            status=form.status.data,
        )
        db.session.add(activity)
        db.session.flush()
        _log("csr.create", "CSRActivity", activity.id, f"Created CSR activity {activity.title}")
        db.session.commit()
        flash("CSR activity created.", "success")
        return redirect(url_for("social.index"))
    return render_template("social/activity_form.html", form=form, is_new=True)


@social_bp.route("/<int:activity_id>")
@login_required
def view_activity(activity_id):
    activity = CSRActivity.query.filter_by(id=activity_id, is_deleted=False).first_or_404()
    participations = activity.participations.filter_by(is_deleted=False).order_by(
        CSRParticipation.registered_at.desc()
    ).all()
    my_participation = next((p for p in participations if p.user_id == current_user.id), None)
    part_form = CSRParticipationForm(obj=my_participation) if my_participation else CSRParticipationForm()
    return render_template(
        "social/activity_detail.html", activity=activity,
        participations=participations, my_participation=my_participation, part_form=part_form,
    )


@social_bp.route("/<int:activity_id>/edit", methods=["GET", "POST"])
@login_required
@permission_required("csr.manage")
def edit_activity(activity_id):
    activity = CSRActivity.query.filter_by(id=activity_id, is_deleted=False).first_or_404()
    form = CSRActivityForm(obj=activity)
    _populate_department_choices(form)
    if request.method == "GET":
        form.department_id.data = activity.department_id or 0

    if form.validate_on_submit():
        activity.title = form.title.data
        activity.description = form.description.data
        activity.category = form.category.data
        activity.department_id = form.department_id.data or None
        activity.location = form.location.data
        activity.activity_date = form.activity_date.data
        activity.budget = form.budget.data or 0
        activity.beneficiaries_target = form.beneficiaries_target.data or 0
        activity.status = form.status.data
        _log("csr.update", "CSRActivity", activity.id, f"Updated CSR activity {activity.title}")
        db.session.commit()
        flash("CSR activity updated.", "success")
        return redirect(url_for("social.view_activity", activity_id=activity.id))
    return render_template("social/activity_form.html", form=form, is_new=False, activity=activity)


@social_bp.route("/<int:activity_id>/delete", methods=["POST"])
@login_required
@permission_required("csr.manage")
def delete_activity(activity_id):
    activity = CSRActivity.query.filter_by(id=activity_id, is_deleted=False).first_or_404()
    activity.soft_delete()
    _log("csr.delete", "CSRActivity", activity.id, f"Deleted CSR activity {activity.title}")
    db.session.commit()
    flash("CSR activity deleted.", "info")
    return redirect(url_for("social.index"))


@social_bp.route("/<int:activity_id>/participate", methods=["POST"])
@login_required
def participate(activity_id):
    activity = CSRActivity.query.filter_by(id=activity_id, is_deleted=False).first_or_404()
    form = CSRParticipationForm()

    participation = CSRParticipation.query.filter_by(
        activity_id=activity.id, user_id=current_user.id, is_deleted=False
    ).first()

    is_new_participation = participation is None

    if participation:
        if form.validate_on_submit():
            participation.hours_contributed = form.hours_contributed.data or 0
            participation.feedback = form.feedback.data
            _log("csr.participate", "CSRParticipation", participation.id, "Updated participation")
    else:
        participation = CSRParticipation(
            activity_id=activity.id, user_id=current_user.id,
            hours_contributed=form.hours_contributed.data or 0, feedback=form.feedback.data,
        )
        db.session.add(participation)
        db.session.flush()
        _log("csr.participate", "CSRParticipation", participation.id, "Registered participation")

    if is_new_participation:
        award_xp(
            current_user, 20, "csr.participated",
            description=f"Joined CSR activity: {activity.title}",
            entity_type="CSRParticipation", entity_id=participation.id,
        )
        update_challenge_progress(current_user, "csr_participation_count", delta=1)

    if float(participation.hours_contributed or 0):
        from app.utils.gamification_service import _user_metric_value
        update_challenge_progress(
            current_user, "csr_hours_total",
            absolute=int(_user_metric_value(current_user, "csr_hours_total")),
        )

    db.session.commit()
    flash("Your participation has been recorded. Thank you!", "success")
    return redirect(url_for("social.view_activity", activity_id=activity.id))


def _populate_department_choices(form):
    dept_query = Department.query.filter_by(is_deleted=False)
    dept_query = _org_scope(dept_query, Department)
    form.department_id.choices = [(0, "— None —")] + [
        (d.id, d.name) for d in dept_query.order_by(Department.name).all()
    ]
