from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user

from app.extensions import db
from app.models.user import User
from app.models.organization import Department
from app.models.gamification import Challenge, ChallengeParticipant, Badge, UserBadge
from app.models.audit import ActivityLog
from app.utils.rbac import permission_required
from app.utils.gamification_forms import ChallengeForm

gamification_bp = Blueprint(
    "gamification", __name__, template_folder="../templates/gamification"
)


def _org_scope(query, model):
    if current_user.organization_id:
        return query.filter(model.organization_id == current_user.organization_id)
    return query


def _log(action, entity_type, entity_id, description):
    ActivityLog.log(
        action=action, user_id=current_user.id, organization_id=current_user.organization_id,
        module="gamification", entity_type=entity_type, entity_id=entity_id,
        description=description, ip_address=request.remote_addr, user_agent=str(request.user_agent),
    )


@gamification_bp.route("/")
@login_required
def index():
    return redirect(url_for("gamification.challenges"))


# --- Challenges --------------------------------------------------------

@gamification_bp.route("/challenges")
@login_required
def challenges():
    page = request.args.get("page", 1, type=int)
    status = request.args.get("status", "")

    query = Challenge.query.filter_by(is_deleted=False)
    query = _org_scope(query, Challenge)
    if status:
        query = query.filter_by(status=status)

    pagination = query.order_by(Challenge.starts_on.desc()).paginate(page=page, per_page=20)

    my_participant_challenge_ids = {
        cp.challenge_id for cp in ChallengeParticipant.query.filter_by(
            user_id=current_user.id, is_deleted=False
        ).all()
    }

    return render_template(
        "gamification/challenges.html", pagination=pagination, status=status,
        my_participant_challenge_ids=my_participant_challenge_ids,
    )


@gamification_bp.route("/challenges/new", methods=["GET", "POST"])
@login_required
@permission_required("challenge.manage")
def new_challenge():
    form = ChallengeForm()
    _populate_department_choices(form)
    if form.validate_on_submit():
        challenge = Challenge(
            organization_id=current_user.organization_id,
            department_id=form.department_id.data or None,
            created_by_id=current_user.id,
            title=form.title.data, description=form.description.data,
            metric=form.metric.data, target_value=form.target_value.data,
            xp_reward=form.xp_reward.data, starts_on=form.starts_on.data,
            ends_on=form.ends_on.data, status=form.status.data,
        )
        db.session.add(challenge)
        db.session.flush()
        _log("challenge.create", "Challenge", challenge.id, f"Created challenge {challenge.title}")
        db.session.commit()
        flash("Challenge created.", "success")
        return redirect(url_for("gamification.challenges"))
    return render_template("gamification/challenge_form.html", form=form, is_new=True)


@gamification_bp.route("/challenges/<int:challenge_id>")
@login_required
def view_challenge(challenge_id):
    challenge = Challenge.query.filter_by(id=challenge_id, is_deleted=False).first_or_404()
    participants = (
        challenge.participants.filter_by(is_deleted=False)
        .order_by(ChallengeParticipant.progress_value.desc())
        .all()
    )
    my_participation = next((p for p in participants if p.user_id == current_user.id), None)
    return render_template(
        "gamification/challenge_detail.html", challenge=challenge,
        participants=participants, my_participation=my_participation,
    )


@gamification_bp.route("/challenges/<int:challenge_id>/edit", methods=["GET", "POST"])
@login_required
@permission_required("challenge.manage")
def edit_challenge(challenge_id):
    challenge = Challenge.query.filter_by(id=challenge_id, is_deleted=False).first_or_404()
    form = ChallengeForm(obj=challenge)
    _populate_department_choices(form)
    if request.method == "GET":
        form.department_id.data = challenge.department_id or 0

    if form.validate_on_submit():
        challenge.title = form.title.data
        challenge.description = form.description.data
        challenge.department_id = form.department_id.data or None
        challenge.metric = form.metric.data
        challenge.target_value = form.target_value.data
        challenge.xp_reward = form.xp_reward.data
        challenge.starts_on = form.starts_on.data
        challenge.ends_on = form.ends_on.data
        challenge.status = form.status.data
        _log("challenge.update", "Challenge", challenge.id, f"Updated challenge {challenge.title}")
        db.session.commit()
        flash("Challenge updated.", "success")
        return redirect(url_for("gamification.view_challenge", challenge_id=challenge.id))
    return render_template("gamification/challenge_form.html", form=form, is_new=False, challenge=challenge)


@gamification_bp.route("/challenges/<int:challenge_id>/delete", methods=["POST"])
@login_required
@permission_required("challenge.manage")
def delete_challenge(challenge_id):
    challenge = Challenge.query.filter_by(id=challenge_id, is_deleted=False).first_or_404()
    challenge.soft_delete()
    _log("challenge.delete", "Challenge", challenge.id, f"Deleted challenge {challenge.title}")
    db.session.commit()
    flash("Challenge deleted.", "info")
    return redirect(url_for("gamification.challenges"))


@gamification_bp.route("/challenges/<int:challenge_id>/join", methods=["POST"])
@login_required
def join_challenge(challenge_id):
    challenge = Challenge.query.filter_by(id=challenge_id, is_deleted=False).first_or_404()
    existing = ChallengeParticipant.query.filter_by(
        challenge_id=challenge.id, user_id=current_user.id, is_deleted=False
    ).first()
    if not existing:
        participant = ChallengeParticipant(
            challenge_id=challenge.id, user_id=current_user.id, progress_value=0,
        )
        db.session.add(participant)
        db.session.flush()
        _log("challenge.join", "ChallengeParticipant", participant.id, f"Joined {challenge.title}")
        db.session.commit()
        flash(f"You joined \u201c{challenge.title}\u201d.", "success")
    else:
        flash("You've already joined this challenge.", "info")
    return redirect(url_for("gamification.view_challenge", challenge_id=challenge.id))


def _populate_department_choices(form):
    dept_query = Department.query.filter_by(is_deleted=False)
    dept_query = _org_scope(dept_query, Department)
    form.department_id.choices = [(0, "\u2014 All Departments \u2014")] + [
        (d.id, d.name) for d in dept_query.order_by(Department.name).all()
    ]


# --- Leaderboard ---------------------------------------------------------

@gamification_bp.route("/leaderboard")
@login_required
def leaderboard():
    query = User.query.filter_by(is_deleted=False, is_active=True)
    query = _org_scope(query, User)
    top_users = query.order_by(User.xp_points.desc()).limit(25).all()
    return render_template("gamification/leaderboard.html", top_users=top_users)


# --- Badges ----------------------------------------------------------------

@gamification_bp.route("/badges")
@login_required
def my_badges():
    earned = (
        UserBadge.query.filter_by(user_id=current_user.id, is_deleted=False)
        .order_by(UserBadge.earned_at.desc())
        .all()
    )
    earned_badge_ids = {ub.badge_id for ub in earned}
    all_badges = Badge.query.filter_by(is_active=True, is_deleted=False).order_by(Badge.criteria_threshold).all()
    locked_badges = [b for b in all_badges if b.id not in earned_badge_ids]
    return render_template(
        "gamification/badges.html", earned=earned, locked_badges=locked_badges,
    )
