from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user

from app.extensions import db
from app.models.governance import Audit, ComplianceIssue
from app.models.user import User
from app.models.audit import ActivityLog
from app.utils.rbac import permission_required
from app.utils.esg_forms import AuditForm, ComplianceIssueForm
from app.utils.gamification_service import award_xp, update_challenge_progress, notify

governance_bp = Blueprint("governance", __name__, template_folder="../templates/governance")


def _org_scope(query, model):
    if current_user.organization_id:
        return query.filter(model.organization_id == current_user.organization_id)
    return query


def _log(action, entity_type, entity_id, description):
    ActivityLog.log(
        action=action, user_id=current_user.id, organization_id=current_user.organization_id,
        module="governance", entity_type=entity_type, entity_id=entity_id,
        description=description, ip_address=request.remote_addr, user_agent=str(request.user_agent),
    )


# --- Audits ------------------------------------------------------------

@governance_bp.route("/")
@login_required
def index():
    return redirect(url_for("governance.audits"))


@governance_bp.route("/audits")
@login_required
def audits():
    page = request.args.get("page", 1, type=int)
    status = request.args.get("status", "")

    query = Audit.query.filter_by(is_deleted=False)
    query = _org_scope(query, Audit)
    if status:
        query = query.filter_by(status=status)

    pagination = query.order_by(Audit.scheduled_date.desc()).paginate(page=page, per_page=20)
    return render_template("governance/audits.html", pagination=pagination, status=status)


@governance_bp.route("/audits/new", methods=["GET", "POST"])
@login_required
@permission_required("audit.conduct")
def new_audit():
    form = AuditForm()
    _populate_auditor_choices(form)
    if form.validate_on_submit():
        audit = Audit(
            organization_id=current_user.organization_id,
            title=form.title.data, audit_type=form.audit_type.data, scope=form.scope.data,
            auditor_id=form.auditor_id.data or None, scheduled_date=form.scheduled_date.data,
            completed_date=form.completed_date.data, status=form.status.data,
            score=form.score.data, findings_summary=form.findings_summary.data,
        )
        db.session.add(audit)
        db.session.flush()
        _log("audit.create", "Audit", audit.id, f"Created audit {audit.title}")
        db.session.commit()
        flash("Audit created.", "success")
        return redirect(url_for("governance.audits"))
    return render_template("governance/audit_form.html", form=form, is_new=True)


@governance_bp.route("/audits/<int:audit_id>")
@login_required
def view_audit(audit_id):
    audit = Audit.query.filter_by(id=audit_id, is_deleted=False).first_or_404()
    issues = audit.issues.filter_by(is_deleted=False).order_by(ComplianceIssue.severity.desc()).all()
    return render_template("governance/audit_detail.html", audit=audit, issues=issues)


@governance_bp.route("/audits/<int:audit_id>/edit", methods=["GET", "POST"])
@login_required
@permission_required("audit.conduct")
def edit_audit(audit_id):
    audit = Audit.query.filter_by(id=audit_id, is_deleted=False).first_or_404()
    form = AuditForm(obj=audit)
    _populate_auditor_choices(form)
    if request.method == "GET":
        form.auditor_id.data = audit.auditor_id or 0

    if form.validate_on_submit():
        was_completed = audit.status == "completed"
        audit.title = form.title.data
        audit.audit_type = form.audit_type.data
        audit.scope = form.scope.data
        audit.auditor_id = form.auditor_id.data or None
        audit.scheduled_date = form.scheduled_date.data
        audit.completed_date = form.completed_date.data
        audit.status = form.status.data
        audit.score = form.score.data
        audit.findings_summary = form.findings_summary.data
        _log("audit.update", "Audit", audit.id, f"Updated audit {audit.title}")
        if not was_completed and audit.status == "completed" and audit.auditor:
            award_xp(
                audit.auditor, 30, "audit.completed",
                description=f"Completed audit: {audit.title}",
                entity_type="Audit", entity_id=audit.id,
            )
        db.session.commit()
        flash("Audit updated.", "success")
        return redirect(url_for("governance.view_audit", audit_id=audit.id))
    return render_template("governance/audit_form.html", form=form, is_new=False, audit=audit)


@governance_bp.route("/audits/<int:audit_id>/delete", methods=["POST"])
@login_required
@permission_required("audit.conduct")
def delete_audit(audit_id):
    audit = Audit.query.filter_by(id=audit_id, is_deleted=False).first_or_404()
    audit.soft_delete()
    _log("audit.delete", "Audit", audit.id, f"Deleted audit {audit.title}")
    db.session.commit()
    flash("Audit deleted.", "info")
    return redirect(url_for("governance.audits"))


def _populate_auditor_choices(form):
    query = User.query.filter_by(is_deleted=False, is_active=True)
    query = _org_scope(query, User)
    form.auditor_id.choices = [(0, "— Unassigned —")] + [
        (u.id, u.full_name) for u in query.order_by(User.first_name).all()
    ]


# --- Compliance issues ---------------------------------------------------

@governance_bp.route("/compliance")
@login_required
def compliance_issues():
    page = request.args.get("page", 1, type=int)
    status = request.args.get("status", "")
    severity = request.args.get("severity", "")

    query = ComplianceIssue.query.filter_by(is_deleted=False)
    query = _org_scope(query, ComplianceIssue)
    if status:
        query = query.filter_by(status=status)
    if severity:
        query = query.filter_by(severity=severity)

    pagination = query.order_by(ComplianceIssue.created_at.desc()).paginate(page=page, per_page=20)
    return render_template(
        "governance/compliance_issues.html", pagination=pagination, status=status, severity=severity
    )


@governance_bp.route("/compliance/new", methods=["GET", "POST"])
@login_required
@permission_required("compliance.manage")
def new_compliance_issue():
    form = ComplianceIssueForm()
    _populate_issue_choices(form)
    if form.validate_on_submit():
        issue = ComplianceIssue(
            organization_id=current_user.organization_id,
            audit_id=form.audit_id.data or None,
            raised_by_id=current_user.id,
            assigned_to_id=form.assigned_to_id.data or None,
            title=form.title.data, description=form.description.data,
            category=form.category.data, severity=form.severity.data,
            status=form.status.data, due_date=form.due_date.data,
        )
        db.session.add(issue)
        db.session.flush()
        _log("compliance.create", "ComplianceIssue", issue.id, f"Raised issue {issue.title}")
        if issue.assigned_to:
            notify(
                issue.assigned_to, "compliance_assigned",
                f"Compliance issue assigned: {issue.title}",
                body=f"Severity: {issue.severity}. Due: {issue.due_date or 'no due date'}.",
                link="/governance/compliance", icon="bi-exclamation-triangle",
            )
        db.session.commit()
        flash("Compliance issue logged.", "success")
        return redirect(url_for("governance.compliance_issues"))
    return render_template("governance/compliance_form.html", form=form, is_new=True)


@governance_bp.route("/compliance/<int:issue_id>/edit", methods=["GET", "POST"])
@login_required
@permission_required("compliance.manage")
def edit_compliance_issue(issue_id):
    issue = ComplianceIssue.query.filter_by(id=issue_id, is_deleted=False).first_or_404()
    form = ComplianceIssueForm(obj=issue)
    _populate_issue_choices(form)
    if request.method == "GET":
        form.audit_id.data = issue.audit_id or 0
        form.assigned_to_id.data = issue.assigned_to_id or 0

    if form.validate_on_submit():
        was_open = issue.status not in ("resolved", "closed")
        issue.title = form.title.data
        issue.description = form.description.data
        issue.category = form.category.data
        issue.audit_id = form.audit_id.data or None
        issue.assigned_to_id = form.assigned_to_id.data or None
        issue.severity = form.severity.data
        issue.status = form.status.data
        issue.due_date = form.due_date.data
        issue.resolution_notes = form.resolution_notes.data
        newly_resolved = was_open and issue.status in ("resolved", "closed")
        if newly_resolved:
            from datetime import datetime
            issue.resolved_at = datetime.utcnow()
        _log("compliance.update", "ComplianceIssue", issue.id, f"Updated issue {issue.title}")
        if newly_resolved and issue.assigned_to:
            award_xp(
                issue.assigned_to, 15, "compliance.resolved",
                description=f"Resolved compliance issue: {issue.title}",
                entity_type="ComplianceIssue", entity_id=issue.id,
            )
            update_challenge_progress(issue.assigned_to, "compliance_resolved_count", delta=1)
        db.session.commit()
        flash("Compliance issue updated.", "success")
        return redirect(url_for("governance.compliance_issues"))
    return render_template("governance/compliance_form.html", form=form, is_new=False, issue=issue)


@governance_bp.route("/compliance/<int:issue_id>/delete", methods=["POST"])
@login_required
@permission_required("compliance.manage")
def delete_compliance_issue(issue_id):
    issue = ComplianceIssue.query.filter_by(id=issue_id, is_deleted=False).first_or_404()
    issue.soft_delete()
    _log("compliance.delete", "ComplianceIssue", issue.id, f"Deleted issue {issue.title}")
    db.session.commit()
    flash("Compliance issue deleted.", "info")
    return redirect(url_for("governance.compliance_issues"))


def _populate_issue_choices(form):
    audit_query = Audit.query.filter_by(is_deleted=False)
    audit_query = _org_scope(audit_query, Audit)
    form.audit_id.choices = [(0, "— None —")] + [
        (a.id, a.title) for a in audit_query.order_by(Audit.scheduled_date.desc()).all()
    ]

    user_query = User.query.filter_by(is_deleted=False, is_active=True)
    user_query = _org_scope(user_query, User)
    form.assigned_to_id.choices = [(0, "— Unassigned —")] + [
        (u.id, u.full_name) for u in user_query.order_by(User.first_name).all()
    ]
