"""
Computes the per-role dashboard metrics and chart-ready datasets consumed by
app/templates/dashboard/*.html. Kept in one module so all seven dashboards
share the same query patterns and JSON shape conventions instead of each
view cooking up its own ad-hoc aggregation.

Every chart dataset returned here is plain JSON-serializable data (lists /
dicts of str, int, float) — Jinja's `tojson` filter handles the rest in the
templates.
"""
from datetime import date, timedelta
from sqlalchemy import func

from app.extensions import db
from app.models.user import User
from app.models.organization import Organization, Department
from app.models.environmental import CarbonTransaction
from app.models.social import CSRActivity, CSRParticipation
from app.models.governance import Audit, ComplianceIssue
from app.models.gamification import Challenge, ChallengeParticipant, UserBadge


def _org_scope(query, model, org_id):
    if org_id:
        return query.filter(model.organization_id == org_id)
    return query


def _month_buckets(n=6):
    """Return n (label, year, month) tuples ending at the current month."""
    today = date.today()
    buckets = []
    y, m = today.year, today.month
    for _ in range(n):
        buckets.append((date(y, m, 1).strftime("%b"), y, m))
        m -= 1
        if m == 0:
            m = 12
            y -= 1
    return list(reversed(buckets))


def carbon_trend(org_id, department_id=None, months=6):
    """Monthly approved CO2e totals, most recent `months` months."""
    buckets = _month_buckets(months)
    labels = [b[0] for b in buckets]
    values = []
    for _, y, m in buckets:
        query = CarbonTransaction.query.filter(
            CarbonTransaction.status == "approved",
            CarbonTransaction.is_deleted.is_(False),
            func.extract("year", CarbonTransaction.activity_date) == y,
            func.extract("month", CarbonTransaction.activity_date) == m,
        )
        query = _org_scope(query, CarbonTransaction, org_id)
        if department_id:
            query = query.filter(CarbonTransaction.department_id == department_id)
        total = sum(float(t.co2e_kg) for t in query.all())
        values.append(round(total, 1))
    return {"labels": labels, "values": values}


def esg_composite_scores(org_id, department_id=None):
    """
    A lightweight composite ESG score per pillar (0-100), derived from
    available data rather than a placeholder:
      - Environmental: inverse of carbon trend (less approved CO2e -> higher score),
        normalized against the org's own trailing 6-month max.
      - Social: CSR participation rate = participants / total users in scope.
      - Governance: average audit score (0-100) across completed audits,
        penalized by open compliance issue count.
    """
    trend = carbon_trend(org_id, department_id, months=6)
    max_co2e = max(trend["values"]) if any(trend["values"]) else 0
    latest_co2e = trend["values"][-1] if trend["values"] else 0
    environmental = 100 if max_co2e == 0 else round(100 * (1 - (latest_co2e / max_co2e)), 1)
    environmental = max(0, min(100, environmental))

    user_query = User.query.filter_by(is_deleted=False, is_active=True)
    user_query = _org_scope(user_query, User, org_id)
    if department_id:
        user_query = user_query.filter(User.department_id == department_id)
    total_users = user_query.count()

    participation_query = CSRParticipation.query.filter_by(is_deleted=False).join(
        User, CSRParticipation.user_id == User.id
    )
    participation_query = _org_scope(participation_query, User, org_id)
    if department_id:
        participation_query = participation_query.filter(User.department_id == department_id)
    participants = participation_query.distinct(CSRParticipation.user_id).count()
    social = round(100 * (participants / total_users), 1) if total_users else 0
    social = max(0, min(100, social))

    audit_query = Audit.query.filter(
        Audit.status == "completed", Audit.is_deleted.is_(False), Audit.score.isnot(None)
    )
    audit_query = _org_scope(audit_query, Audit, org_id)
    audit_scores = [float(a.score) for a in audit_query.all()]
    avg_audit_score = sum(audit_scores) / len(audit_scores) if audit_scores else 70.0

    open_issues_query = ComplianceIssue.query.filter(
        ComplianceIssue.status.in_(["open", "in_progress"]),
        ComplianceIssue.is_deleted.is_(False),
    )
    open_issues_query = _org_scope(open_issues_query, ComplianceIssue, org_id)
    open_issue_count = open_issues_query.count()
    governance = max(0, min(100, round(avg_audit_score - (open_issue_count * 3), 1)))

    overall = round((environmental + social + governance) / 3, 1)
    return {
        "overall": overall, "environmental": environmental,
        "social": social, "governance": governance,
    }


def csr_participation_by_category(org_id, department_id=None):
    query = CSRActivity.query.filter_by(is_deleted=False)
    query = _org_scope(query, CSRActivity, org_id)
    if department_id:
        query = query.filter(CSRActivity.department_id == department_id)
    counts = {}
    for activity in query.all():
        counts[activity.category] = counts.get(activity.category, 0) + activity.participant_count
    labels = [c.replace("_", " ").title() for c in counts.keys()] or ["No data"]
    values = list(counts.values()) or [0]
    return {"labels": labels, "values": values}


def audit_compliance_stats(org_id):
    query = Audit.query.filter_by(is_deleted=False)
    query = _org_scope(query, Audit, org_id)
    status_counts = {"scheduled": 0, "in_progress": 0, "completed": 0, "cancelled": 0}
    for a in query.all():
        status_counts[a.status] = status_counts.get(a.status, 0) + 1

    issues_query = ComplianceIssue.query.filter_by(is_deleted=False)
    issues_query = _org_scope(issues_query, ComplianceIssue, org_id)
    severity_counts = {"low": 0, "medium": 0, "high": 0, "critical": 0}
    for i in issues_query.all():
        severity_counts[i.severity] = severity_counts.get(i.severity, 0) + 1

    return {
        "audit_labels": list(status_counts.keys()),
        "audit_values": list(status_counts.values()),
        "severity_labels": list(severity_counts.keys()),
        "severity_values": list(severity_counts.values()),
    }


def leaderboard_snippet(org_id, limit=5):
    query = User.query.filter_by(is_deleted=False, is_active=True)
    query = _org_scope(query, User, org_id)
    top = query.order_by(User.xp_points.desc()).limit(limit).all()
    return [{"name": u.full_name, "xp": u.xp_points, "level": u.level} for u in top]


def xp_progress(user):
    from app.utils.gamification_service import xp_for_level, LEVEL_XP_STEP
    current_floor = xp_for_level(user.level)
    next_ceiling = xp_for_level(user.level + 1)
    span = max(1, next_ceiling - current_floor)
    progress_in_level = user.xp_points - current_floor
    pct = max(0, min(100, round(100 * progress_in_level / span, 1)))
    return {
        "current": user.xp_points, "level": user.level,
        "next_level_at": next_ceiling, "pct": pct,
    }


def kpi_summary(org_id, department_id=None):
    """Common KPI numbers reused across dashboards."""
    scores = esg_composite_scores(org_id, department_id)

    pending_query = CarbonTransaction.query.filter_by(status="pending", is_deleted=False)
    pending_query = _org_scope(pending_query, CarbonTransaction, org_id)
    if department_id:
        pending_query = pending_query.filter(CarbonTransaction.department_id == department_id)
    pending_approvals = pending_query.count()

    open_issues_query = ComplianceIssue.query.filter(
        ComplianceIssue.status.in_(["open", "in_progress"]), ComplianceIssue.is_deleted.is_(False)
    )
    open_issues_query = _org_scope(open_issues_query, ComplianceIssue, org_id)
    open_issues = open_issues_query.count()

    overdue_query = ComplianceIssue.query.filter(
        ComplianceIssue.status.in_(["open", "in_progress"]),
        ComplianceIssue.due_date.isnot(None),
        ComplianceIssue.due_date < date.today(),
        ComplianceIssue.is_deleted.is_(False),
    )
    overdue_query = _org_scope(overdue_query, ComplianceIssue, org_id)
    overdue_actions = overdue_query.count()

    active_challenges_query = Challenge.query.filter_by(status="active", is_deleted=False)
    active_challenges_query = _org_scope(active_challenges_query, Challenge, org_id)
    active_challenges = active_challenges_query.count()

    thirty_days_ago = date.today() - timedelta(days=30)
    badges_query = UserBadge.query.filter(
        UserBadge.earned_at >= thirty_days_ago, UserBadge.is_deleted.is_(False)
    ).join(User, UserBadge.user_id == User.id)
    badges_query = _org_scope(badges_query, User, org_id)
    badges_30d = badges_query.count()

    return {
        "scores": scores,
        "pending_approvals": pending_approvals,
        "open_compliance_issues": open_issues,
        "overdue_corrective_actions": overdue_actions,
        "active_challenges": active_challenges,
        "badges_unlocked_30d": badges_30d,
    }
