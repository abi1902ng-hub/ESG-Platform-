from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, IntegerField, DateField, SubmitField
from wtforms.validators import DataRequired, Length, Optional, NumberRange, ValidationError

METRIC_CHOICES = [
    ("carbon_logged_count", "Carbon Transactions Logged"),
    ("csr_hours_total", "CSR Hours Contributed"),
    ("csr_participation_count", "CSR Activities Joined"),
    ("compliance_resolved_count", "Compliance Issues Resolved"),
    ("xp_earned", "XP Earned"),
]
STATUS_CHOICES = [
    ("draft", "Draft"), ("active", "Active"), ("completed", "Completed"), ("cancelled", "Cancelled"),
]


class ChallengeForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired(), Length(max=150)])
    description = TextAreaField("Description", validators=[Optional()])
    department_id = SelectField("Department", coerce=int, validators=[Optional()])
    metric = SelectField("Metric", choices=METRIC_CHOICES, validators=[DataRequired()])
    target_value = IntegerField("Target Value", validators=[DataRequired(), NumberRange(min=1)])
    xp_reward = IntegerField("XP Reward", default=50, validators=[DataRequired(), NumberRange(min=0)])
    starts_on = DateField("Starts On", validators=[DataRequired()])
    ends_on = DateField("Ends On", validators=[DataRequired()])
    status = SelectField("Status", choices=STATUS_CHOICES, validators=[DataRequired()])
    submit = SubmitField("Save Challenge")

    def validate_ends_on(self, field):
        if self.starts_on.data and field.data and field.data < self.starts_on.data:
            raise ValidationError("End date must be on or after the start date.")
