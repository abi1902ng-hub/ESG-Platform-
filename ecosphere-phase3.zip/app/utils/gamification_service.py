"""
Core gamification logic, called from environmental/social/governance routes
whenever a user does something XP-worthy. Kept framework-light (plain
functions, not a class) so it's easy to call from anywhere without an import
cycle: this module imports models, but no route module needs to import
gamification routes to award XP.

Usage:
    from app.utils.gamification_service import award_xp
    award_xp(user, 15, "carbon.approved", entity_type="CarbonTransaction", entity_id=txn.id)

`award_xp` handles: writing the ledger row, bumping the denormalized total,
recomputing level, checking for newly-earned badges, updating any active
challenge progress for that user's metric, and creating notifications for
level-ups / badges / challenge completions. It does NOT commit — the caller
controls the transaction, matching the existing route convention of a single
db.session.commit() per request.
"""
from datetime import datetime
from app.extensions import db
from app.models.gamification import (
    XPTransaction, Badge, UserBadge, Challenge, ChallengeParticipant,
)
from app.models.notification import Notification

# XP required to reach a given level: level N requires N * LEVEL_XP_STEP
# cumulative XP. Simple linear curve, easy to tune later.
LEVEL_XP_STEP = 100


def xp_for_level(level: int) -> int:
    """Total cumulative XP required to *reach* this level."""
    return max(0, level - 1) * LEVEL_XP_STEP


def level_for_xp(xp: int) -> int:
    return (xp // LEVEL_XP_STEP) + 1


def notify(user, notif_type, title, body=None, link=None, icon="bi-bell"):
    n = Notification(
        user_id=user.id, notif_type=notif_type, title=title,
        body=body, link=link, icon=icon,
    )
    db.session.add(n)
    return n


def award_xp(user, amount, reason_code, coins=0, description=None,
             entity_type=None, entity_id=None):
    """
    Central entry point for granting XP (and optionally coins) to a user.
    Writes the ledger, updates denormalized totals, handles level-up
    notifications, re-checks badges, and updates any challenges the user is
    enrolled in whose metric this action affects.
    """
    if amount == 0 and coins == 0:
        return None

    txn = XPTransaction(
        user_id=user.id, amount=amount, coins=coins,
        reason_code=reason_code, description=description,
        entity_type=entity_type, entity_id=entity_id,
    )
    db.session.add(txn)

    old_level = user.level
    user.xp_points = max(0, user.xp_points + amount)
    user.coins = max(0, user.coins + coins)
    user.level = level_for_xp(user.xp_points)

    if user.level > old_level:
        notify(
            user, "general", f"Level up! You're now level {user.level}",
            body=f"You earned {amount} XP and reached level {user.level}.",
            icon="bi-stars",
        )

    check_and_award_badges(user)
    return txn


def _user_metric_value(user, criteria_type: str) -> int:
    """Compute a user's current lifetime count for a given badge criteria type."""
    from app.models.environmental import CarbonTransaction
    from app.models.social import CSRParticipation
    from app.models.governance import Audit, ComplianceIssue

    if criteria_type == "xp_total":
        return user.xp_points
    if criteria_type == "carbon_logged_count":
        return CarbonTransaction.query.filter_by(
            logged_by_id=user.id, is_deleted=False
        ).count()
    if criteria_type == "csr_hours_total":
        total = db.session.query(
            db.func.coalesce(db.func.sum(CSRParticipation.hours_contributed), 0)
        ).filter(
            CSRParticipation.user_id == user.id, CSRParticipation.is_deleted.is_(False)
        ).scalar()
        return int(total or 0)
    if criteria_type == "csr_participation_count":
        return CSRParticipation.query.filter_by(
            user_id=user.id, is_deleted=False
        ).count()
    if criteria_type == "audit_completed_count":
        return Audit.query.filter_by(
            auditor_id=user.id, status="completed", is_deleted=False
        ).count()
    if criteria_type == "compliance_resolved_count":
        return ComplianceIssue.query.filter(
            ComplianceIssue.assigned_to_id == user.id,
            ComplianceIssue.status.in_(["resolved", "closed"]),
            ComplianceIssue.is_deleted.is_(False),
        ).count()
    if criteria_type == "challenge_completed_count":
        return ChallengeParticipant.query.filter(
            ChallengeParticipant.user_id == user.id,
            ChallengeParticipant.completed_at.isnot(None),
            ChallengeParticipant.is_deleted.is_(False),
        ).count()
    return 0


def check_and_award_badges(user):
    """Re-evaluate every active badge definition against the user's current
    stats and award any newly-unlocked ones. Safe to call repeatedly —
    already-earned badges are skipped."""
    earned_ids = {
        ub.badge_id for ub in UserBadge.query.filter_by(user_id=user.id, is_deleted=False).all()
    }
    newly_earned = []
    for badge in Badge.query.filter_by(is_active=True, is_deleted=False).all():
        if badge.id in earned_ids:
            continue
        value = _user_metric_value(user, badge.criteria_type)
        if value >= badge.criteria_threshold:
            ub = UserBadge(user_id=user.id, badge_id=badge.id)
            db.session.add(ub)
            newly_earned.append(badge)

    for badge in newly_earned:
        if badge.xp_reward:
            user.xp_points += badge.xp_reward
            user.level = level_for_xp(user.xp_points)
            db.session.add(XPTransaction(
                user_id=user.id, amount=badge.xp_reward, coins=0,
                reason_code="badge.earned", description=f"Badge unlocked: {badge.name}",
                entity_type="Badge", entity_id=badge.id,
            ))
        notify(
            user, "badge_earned", f"Badge unlocked: {badge.name}",
            body=badge.description, icon=badge.icon,
        )
    return newly_earned


def update_challenge_progress(user, metric, delta=None, absolute=None):
    """
    Update progress for every active challenge the user is enrolled in that
    tracks `metric`. Pass `delta` to increment, or `absolute` to set the
    value directly (absolute wins if both given). Marks the participant
    completed + awards XP + notifies exactly once, the moment target is hit.
    """
    today = datetime.utcnow().date()
    participations = (
        ChallengeParticipant.query
        .join(Challenge, ChallengeParticipant.challenge_id == Challenge.id)
        .filter(
            ChallengeParticipant.user_id == user.id,
            ChallengeParticipant.is_deleted.is_(False),
            ChallengeParticipant.completed_at.is_(None),
            Challenge.metric == metric,
            Challenge.status == "active",
            Challenge.starts_on <= today,
            Challenge.ends_on >= today,
            Challenge.is_deleted.is_(False),
        )
        .all()
    )

    for participation in participations:
        if absolute is not None:
            participation.progress_value = absolute
        elif delta is not None:
            participation.progress_value += delta

        challenge = participation.challenge
        if participation.progress_value >= challenge.target_value:
            participation.completed_at = datetime.utcnow()
            if challenge.xp_reward:
                award_xp(
                    user, challenge.xp_reward, "challenge.completed",
                    description=f"Completed challenge: {challenge.title}",
                    entity_type="Challenge", entity_id=challenge.id,
                )
            notify(
                user, "challenge_completed", f"Challenge completed: {challenge.title}",
                body=f"You earned {challenge.xp_reward} XP.",
                link="/gamification/challenges", icon="bi-flag-fill",
            )
