/**
 * Small helper so every Chart.js instance across the dashboards shares one
 * palette pulled straight from theme.css's CSS variables, instead of each
 * dashboard template hardcoding hex values that would drift from the design
 * tokens (and wouldn't adapt to the dark-mode toggle).
 */
window.EcoChartTheme = (function () {
  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  function palette() {
    return {
      sage: cssVar("--sage-500") || "#6fa98a",
      sageStrong: cssVar("--accent-primary-strong") || "#4f8a6c",
      amber: cssVar("--amber-500") || "#e3a94b",
      clay: cssVar("--clay-500") || "#c9704f",
      slate: cssVar("--slate-700") || "#2f4858",
      danger: cssVar("--accent-danger") || "#c1483f",
      textSecondary: cssVar("--text-secondary") || "#5c7686",
      border: cssVar("--border-subtle") || "#e4e0d4",
      fontBody: cssVar("--font-body") || "Inter, sans-serif",
      fontMono: cssVar("--font-mono") || "monospace",
    };
  }

  function defaults() {
    const p = palette();
    if (window.Chart) {
      Chart.defaults.font.family = p.fontBody;
      Chart.defaults.color = p.textSecondary;
      Chart.defaults.borderColor = p.border;
      Chart.defaults.plugins.legend.labels.usePointStyle = true;
      Chart.defaults.plugins.legend.labels.boxWidth = 8;
    }
    return p;
  }

  // Sequential category palette for pie/doughnut/bar-by-category charts.
  function categorySeries() {
    const p = palette();
    return [p.sage, p.amber, p.slate, p.clay, p.sageStrong, p.danger];
  }

  return { palette, defaults, categorySeries };
})();
