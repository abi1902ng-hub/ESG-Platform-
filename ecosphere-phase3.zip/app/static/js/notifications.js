/**
 * Lazy-loads the notification dropdown's contents the first time the bell
 * is opened, and re-fetches each time it's reopened so unread state stays
 * fresh across page navigations without a full reload.
 */
(function () {
  const bellBtn = document.getElementById("notifBellBtn");
  const panel = document.getElementById("notifDropdownPanel");
  const dot = document.getElementById("notifDot");
  if (!bellBtn || !panel) return;

  const dropdownUrl = panel.dataset.dropdownUrl;

  function loadDropdown() {
    panel.innerHTML = '<div class="notif-header">Notifications</div><div class="notif-empty text-muted small p-3">Loading…</div>';
    fetch(dropdownUrl, { headers: { "X-Requested-With": "XMLHttpRequest" } })
      .then((res) => res.text())
      .then((html) => {
        panel.innerHTML = html;
        wireMarkRead();
        wireMarkAllRead();
      })
      .catch(() => {
        panel.innerHTML = '<div class="notif-header">Notifications</div><div class="notif-empty text-muted small p-3">Couldn\'t load notifications.</div>';
      });
  }

  function wireMarkRead() {
    panel.querySelectorAll(".notif-item[data-notif-id]").forEach((el) => {
      el.addEventListener("click", function (e) {
        const notifId = this.dataset.notifId;
        const href = this.getAttribute("href");
        // Fire-and-forget mark-as-read; let the browser follow the link normally.
        fetch(`/notifications/${notifId}/read`, {
          method: "POST",
          headers: { "X-Requested-With": "XMLHttpRequest" },
        }).catch(() => {});
        if (dot) dot.remove();
      });
    });
  }

  function wireMarkAllRead() {
    const form = panel.querySelector(".mark-all-read-form");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      fetch(form.action, {
        method: "POST",
        headers: { "X-Requested-With": "XMLHttpRequest" },
      })
        .then(() => {
          if (dot) dot.remove();
          loadDropdown();
        })
        .catch(() => {});
    });
  }

  bellBtn.addEventListener("click", loadDropdown);
})();
