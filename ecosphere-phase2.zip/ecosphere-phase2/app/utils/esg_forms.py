from flask_wtf import FlaskForm
from wtforms import (
    StringField, TextAreaField, SelectField, DecimalField, IntegerField,
    DateField, SubmitField,
)
from wtforms.validators import DataRequired, Length, Optional, NumberRange

# ---------------------------------------------------------------------------
# Environmental
# ---------------------------------------------------------------------------

SCOPE_CHOICES = [("scope_1", "Scope 1 — Direct"), ("scope_2", "Scope 2 — Energy"), ("scope_3", "Scope 3 — Value Chain")]


class EmissionFactorForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired(), Length(max=150)])
    scope = SelectField("Scope", choices=SCOPE_CHOICES, validators=[DataRequired()])
    category = StringField("Category", validators=[DataRequired(), Length(max=80)])
    unit = StringField("Unit", validators=[DataRequired(), Length(max=30)])
    factor_value = DecimalField("kg CO2e per unit", places=6, validators=[DataRequired()])
    source = StringField("Source", validators=[Optional(), Length(max=150)])
    submit = SubmitField("Save Factor")


class CarbonTransactionForm(FlaskForm):
    department_id = SelectField("Department", coerce=int, validators=[Optional()])
    emission_factor_id = SelectField("Emission Factor", coerce=int, validators=[DataRequired()])
    activity_date = DateField("Activity Date", validators=[DataRequired()])
    quantity = DecimalField("Quantity", places=4, validators=[DataRequired(), NumberRange(min=0)])
    notes = StringField("Notes", validators=[Optional(), Length(max=500)])
    submit = SubmitField("Log Transaction")


class RejectTransactionForm(FlaskForm):
    rejection_reason = StringField("Reason", validators=[DataRequired(), Length(max=300)])
    submit = SubmitField("Reject")


# ---------------------------------------------------------------------------
# Social / CSR
# ---------------------------------------------------------------------------

CSR_CATEGORY_CHOICES = [
    ("community", "Community"), ("education", "Education"), ("environment", "Environment"),
    ("health", "Health"), ("diversity", "Diversity & Inclusion"), ("disaster_relief", "Disaster Relief"),
]
CSR_STATUS_CHOICES = [
    ("planned", "Planned"), ("ongoing", "Ongoing"), ("completed", "Completed"), ("cancelled", "Cancelled"),
]


class CSRActivityForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired(), Length(max=150)])
    description = TextAreaField("Description", validators=[Optional()])
    category = SelectField("Category", choices=CSR_CATEGORY_CHOICES, validators=[DataRequired()])
    department_id = SelectField("Department", coerce=int, validators=[Optional()])
    location = StringField("Location", validators=[Optional(), Length(max=150)])
    activity_date = DateField("Date", validators=[DataRequired()])
    budget = DecimalField("Budget (INR)", places=2, validators=[Optional(), NumberRange(min=0)])
    beneficiaries_target = IntegerField("Beneficiaries Target", validators=[Optional(), NumberRange(min=0)])
    status = SelectField("Status", choices=CSR_STATUS_CHOICES, validators=[DataRequired()])
    submit = SubmitField("Save Activity")


class CSRParticipationForm(FlaskForm):
    hours_contributed = DecimalField("Hours Contributed", places=2, validators=[Optional(), NumberRange(min=0)])
    feedback = StringField("Feedback", validators=[Optional(), Length(max=500)])
    submit = SubmitField("Log Participation")


# ---------------------------------------------------------------------------
# Governance
# ---------------------------------------------------------------------------

AUDIT_TYPE_CHOICES = [
    ("internal", "Internal"), ("external", "External"),
    ("regulatory", "Regulatory"), ("supplier", "Supplier"),
]
AUDIT_STATUS_CHOICES = [
    ("scheduled", "Scheduled"), ("in_progress", "In Progress"),
    ("completed", "Completed"), ("cancelled", "Cancelled"),
]


class AuditForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired(), Length(max=150)])
    audit_type = SelectField("Type", choices=AUDIT_TYPE_CHOICES, validators=[DataRequired()])
    scope = TextAreaField("Scope", validators=[Optional()])
    auditor_id = SelectField("Assigned Auditor", coerce=int, validators=[Optional()])
    scheduled_date = DateField("Scheduled Date", validators=[DataRequired()])
    completed_date = DateField("Completed Date", validators=[Optional()])
    status = SelectField("Status", choices=AUDIT_STATUS_CHOICES, validators=[DataRequired()])
    score = DecimalField("Compliance Score (0-100)", places=2, validators=[Optional(), NumberRange(min=0, max=100)])
    findings_summary = TextAreaField("Findings Summary", validators=[Optional()])
    submit = SubmitField("Save Audit")


ISSUE_SEVERITY_CHOICES = [("low", "Low"), ("medium", "Medium"), ("high", "High"), ("critical", "Critical")]
ISSUE_STATUS_CHOICES = [
    ("open", "Open"), ("in_progress", "In Progress"), ("resolved", "Resolved"), ("closed", "Closed"),
]


class ComplianceIssueForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired(), Length(max=150)])
    description = TextAreaField("Description", validators=[Optional()])
    category = StringField("Category", validators=[Optional(), Length(max=80)])
    audit_id = SelectField("Related Audit", coerce=int, validators=[Optional()])
    assigned_to_id = SelectField("Assigned To", coerce=int, validators=[Optional()])
    severity = SelectField("Severity", choices=ISSUE_SEVERITY_CHOICES, validators=[DataRequired()])
    status = SelectField("Status", choices=ISSUE_STATUS_CHOICES, validators=[DataRequired()])
    due_date = DateField("Due Date", validators=[Optional()])
    resolution_notes = StringField("Resolution Notes", validators=[Optional(), Length(max=500)])
    submit = SubmitField("Save Issue")
