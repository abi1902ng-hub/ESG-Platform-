"""
Seeds the database with:
  - 7 system roles
  - a baseline permission set per module (extended in later phases)
  - a demo organization + department
  - one demo user per role, so every dashboard can be reviewed immediately

Run with:  python -m app.utils.seed
"""
from datetime import date, timedelta

from app import create_app
from app.extensions import db
from app.models.user import User, Role, Permission, SYSTEM_ROLES
from app.models.organization import Organization, Department
from app.models.environmental import EmissionFactor, CarbonTransaction
from app.models.social import CSRActivity, CSRParticipation
from app.models.governance import Audit, ComplianceIssue


ROLE_META = {
    "super_admin": ("Super Admin", "Full platform access across all organizations."),
    "org_admin": ("Organization Admin", "Full access within their organization."),
    "department_manager": ("Department Manager", "Manages a department's team, approvals, and goals."),
    "employee": ("Employee", "Logs personal activity, CSR participation, and challenges."),
    "auditor": ("Auditor", "Conducts audits and tracks compliance issues."),
    "csr_manager": ("CSR Manager", "Manages CSR activities, challenges, and rewards."),
    "viewer": ("Viewer", "Read-only access to ESG performance."),
}

# Baseline permission catalog. Later phases (environmental / social /
# governance / gamification) will register their own module-specific codes
# through the same Permission table without altering this seed's shape.
BASE_PERMISSIONS = [
    ("user.manage", "admin", "Create, update, deactivate users"),
    ("role.manage", "admin", "Manage roles and permissions"),
    ("department.manage", "admin", "Manage departments"),
    ("org.settings", "admin", "Manage organization settings"),
    ("report.view", "reports", "View generated reports"),
    ("report.export", "reports", "Export reports (PDF/Excel/CSV)"),
    ("audit.conduct", "governance", "Conduct internal audits"),
    ("compliance.manage", "governance", "Manage compliance issues"),
    ("csr.manage", "social", "Manage CSR activities and approvals"),
    ("challenge.manage", "gamification", "Manage challenges and rewards"),
    ("carbon.log", "environmental", "Log carbon-relevant transactions"),
    ("carbon.approve", "environmental", "Approve or reject carbon transactions"),
    ("factor.manage", "environmental", "Manage emission factor reference data"),
]

ROLE_PERMISSIONS = {
    "super_admin": [code for code, _, _ in BASE_PERMISSIONS],
    "org_admin": [code for code, _, _ in BASE_PERMISSIONS],
    "department_manager": [
        "report.view", "csr.manage", "challenge.manage", "carbon.log", "carbon.approve",
    ],
    "employee": ["carbon.log"],
    "auditor": [
        "audit.conduct", "compliance.manage", "report.view", "report.export",
        "carbon.approve", "factor.manage",
    ],
    "csr_manager": ["csr.manage", "challenge.manage", "report.view", "carbon.log"],
    "viewer": ["report.view"],
}

DEMO_PASSWORD = "Ecosphere@123"


def seed():
    app = create_app()
    with app.app_context():
        db.create_all()

        # --- roles -----------------------------------------------------
        roles = {}
        for name in SYSTEM_ROLES:
            role = Role.query.filter_by(name=name).first()
            if not role:
                display_name, description = ROLE_META[name]
                role = Role(name=name, display_name=display_name, description=description)
                db.session.add(role)
            roles[name] = role
        db.session.flush()

        # --- permissions -------------------------------------------------
        perms = {}
        for code, module, description in BASE_PERMISSIONS:
            perm = Permission.query.filter_by(code=code).first()
            if not perm:
                perm = Permission(code=code, module=module, description=description)
                db.session.add(perm)
            perms[code] = perm
        db.session.flush()

        for role_name, codes in ROLE_PERMISSIONS.items():
            role = roles[role_name]
            for code in codes:
                if perms[code] not in role.permissions:
                    role.permissions.append(perms[code])

        # --- demo organization + department -----------------------------
        org = Organization.query.filter_by(name="AstraVantage Demo Corp").first()
        if not org:
            org = Organization(
                name="AstraVantage Demo Corp",
                industry="Technology",
                country="India",
                timezone="Asia/Kolkata",
            )
            db.session.add(org)
            db.session.flush()

        dept = Department.query.filter_by(organization_id=org.id, code="OPS").first()
        if not dept:
            dept = Department(
                organization_id=org.id,
                name="Operations",
                code="OPS",
                description="Core operations department (demo seed).",
            )
            db.session.add(dept)
            db.session.flush()

        # --- one demo user per role ---------------------------------------
        for role_name in SYSTEM_ROLES:
            email = f"{role_name}@ecosphere.demo"
            user = User.query.filter_by(email=email).first()
            if user:
                continue
            display_name, _ = ROLE_META[role_name]
            first, *rest = display_name.split(" ")
            user = User(
                organization_id=org.id if role_name != "super_admin" else None,
                department_id=dept.id if role_name in ("department_manager", "employee") else None,
                role_id=roles[role_name].id,
                first_name=first,
                last_name=" ".join(rest) or "Demo",
                email=email,
                is_active=True,
                is_email_verified=True,
            )
            user.set_password(DEMO_PASSWORD)
            db.session.add(user)

        db.session.flush()

        # --- Phase 2 demo data: emission factors, a carbon transaction,
        #     a CSR activity, an audit + compliance issue ------------------
        users_by_role = {r: User.query.filter_by(email=f"{r}@ecosphere.demo").first() for r in SYSTEM_ROLES}

        factor = EmissionFactor.query.filter_by(name="Grid Electricity (India)").first()
        if not factor:
            factor = EmissionFactor(
                organization_id=None,  # global factor
                name="Grid Electricity (India)", scope="scope_2", category="electricity",
                unit="kWh", factor_value=0.82, source="CEA India 2024",
            )
            db.session.add(factor)
            db.session.flush()

        employee = users_by_role.get("employee")
        if employee and not CarbonTransaction.query.filter_by(organization_id=org.id).first():
            txn = CarbonTransaction(
                organization_id=org.id, department_id=dept.id, logged_by_id=employee.id,
                emission_factor_id=factor.id, activity_date=date.today() - timedelta(days=3),
                quantity=450, notes="Office electricity usage — March.",
                co2e_kg=450 * float(factor.factor_value),
            )
            db.session.add(txn)

        csr_manager = users_by_role.get("csr_manager")
        if csr_manager and not CSRActivity.query.filter_by(organization_id=org.id).first():
            activity = CSRActivity(
                organization_id=org.id, department_id=dept.id,
                title="Community Tree Plantation Drive",
                description="Plant native saplings with local schoolchildren.",
                category="environment", location="Coimbatore, TN",
                activity_date=date.today() + timedelta(days=14), budget=25000,
                beneficiaries_target=100, status="planned",
            )
            db.session.add(activity)

        auditor = users_by_role.get("auditor")
        if auditor and not Audit.query.filter_by(organization_id=org.id).first():
            audit_rec = Audit(
                organization_id=org.id, auditor_id=auditor.id,
                title="Q1 ESG Compliance Review", audit_type="internal",
                scope="Review environmental and governance controls for Q1.",
                scheduled_date=date.today() + timedelta(days=7), status="scheduled",
            )
            db.session.add(audit_rec)
            db.session.flush()

            issue = ComplianceIssue(
                organization_id=org.id, audit_id=audit_rec.id, raised_by_id=auditor.id,
                title="Missing supplier ESG disclosures",
                description="Two key suppliers have not submitted required ESG disclosures.",
                category="supply_chain", severity="medium", status="open",
                due_date=date.today() + timedelta(days=30),
            )
            db.session.add(issue)

        db.session.commit()
        print("Seed complete.")
        print(f"Demo password for all seeded users: {DEMO_PASSWORD}")
        for role_name in SYSTEM_ROLES:
            print(f"  {role_name:22s} -> {role_name}@ecosphere.demo")


if __name__ == "__main__":
    seed()
