from datetime import datetime
from app.extensions import db
from app.models.base import BaseModel

CSR_CATEGORIES = ["community", "education", "environment", "health", "diversity", "disaster_relief"]
CSR_STATUSES = ["planned", "ongoing", "completed", "cancelled"]


class CSRActivity(BaseModel):
    """A CSR initiative organized by an org (tree planting, blood drive, etc.)."""

    __tablename__ = "csr_activities"

    organization_id = db.Column(
        db.Integer, db.ForeignKey("organizations.id"), nullable=False, index=True
    )
    department_id = db.Column(db.Integer, db.ForeignKey("departments.id"), nullable=True, index=True)

    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(30), nullable=False, default="community")
    location = db.Column(db.String(150))
    activity_date = db.Column(db.Date, nullable=False)
    budget = db.Column(db.Numeric(12, 2), default=0)
    beneficiaries_target = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), nullable=False, default="planned", index=True)

    department = db.relationship("Department", foreign_keys=[department_id])
    participations = db.relationship(
        "CSRParticipation", backref="activity", lazy="dynamic",
        cascade="all, delete-orphan",
    )

    @property
    def total_hours(self):
        return sum(
            float(p.hours_contributed or 0)
            for p in self.participations.filter_by(is_deleted=False)
        )

    @property
    def participant_count(self):
        return self.participations.filter_by(is_deleted=False).count()

    def __repr__(self):
        return f"<CSRActivity {self.title}>"


class CSRParticipation(BaseModel):
    """An employee signing up / logging hours against a CSR activity."""

    __tablename__ = "csr_participations"

    activity_id = db.Column(db.Integer, db.ForeignKey("csr_activities.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    hours_contributed = db.Column(db.Numeric(6, 2), default=0)
    feedback = db.Column(db.String(500))
    registered_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", foreign_keys=[user_id])

    __table_args__ = (
        db.UniqueConstraint("activity_id", "user_id", name="uq_participation_activity_user"),
    )

    def __repr__(self):
        return f"<CSRParticipation user={self.user_id} activity={self.activity_id}>"
