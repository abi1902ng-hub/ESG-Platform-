from datetime import datetime
from app.extensions import db
from app.models.base import BaseModel

AUDIT_TYPES = ["internal", "external", "regulatory", "supplier"]
AUDIT_STATUSES = ["scheduled", "in_progress", "completed", "cancelled"]
ISSUE_SEVERITIES = ["low", "medium", "high", "critical"]
ISSUE_STATUSES = ["open", "in_progress", "resolved", "closed"]


class Audit(BaseModel):
    """A compliance/ESG audit conducted against an organization."""

    __tablename__ = "audits"

    organization_id = db.Column(
        db.Integer, db.ForeignKey("organizations.id"), nullable=False, index=True
    )
    auditor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)

    title = db.Column(db.String(150), nullable=False)
    audit_type = db.Column(db.String(30), nullable=False, default="internal")
    scope = db.Column(db.Text)
    scheduled_date = db.Column(db.Date, nullable=False)
    completed_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(20), nullable=False, default="scheduled", index=True)
    score = db.Column(db.Numeric(5, 2), nullable=True)  # 0-100 compliance score
    findings_summary = db.Column(db.Text)

    auditor = db.relationship("User", foreign_keys=[auditor_id])
    issues = db.relationship(
        "ComplianceIssue", backref="audit", lazy="dynamic", foreign_keys="ComplianceIssue.audit_id"
    )

    @property
    def open_issue_count(self):
        return self.issues.filter(
            ComplianceIssue.status.in_(["open", "in_progress"]),
            ComplianceIssue.is_deleted.is_(False),
        ).count()

    def __repr__(self):
        return f"<Audit {self.title} ({self.status})>"


class ComplianceIssue(BaseModel):
    """A finding/issue that needs to be tracked to resolution, optionally tied to an audit."""

    __tablename__ = "compliance_issues"

    organization_id = db.Column(
        db.Integer, db.ForeignKey("organizations.id"), nullable=False, index=True
    )
    audit_id = db.Column(db.Integer, db.ForeignKey("audits.id"), nullable=True, index=True)
    raised_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    assigned_to_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)

    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(80))  # e.g. "data privacy", "labor", "environmental permit"
    severity = db.Column(db.String(20), nullable=False, default="medium", index=True)
    status = db.Column(db.String(20), nullable=False, default="open", index=True)
    due_date = db.Column(db.Date, nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)
    resolution_notes = db.Column(db.String(500))

    raised_by = db.relationship("User", foreign_keys=[raised_by_id])
    assigned_to = db.relationship("User", foreign_keys=[assigned_to_id])

    def resolve(self, notes=None):
        self.status = "resolved"
        self.resolved_at = datetime.utcnow()
        if notes:
            self.resolution_notes = notes

    def __repr__(self):
        return f"<ComplianceIssue {self.title} ({self.severity}/{self.status})>"
