from datetime import datetime
from app.extensions import db
from app.models.base import BaseModel

SCOPES = ["scope_1", "scope_2", "scope_3"]
TRANSACTION_STATUSES = ["pending", "approved", "rejected"]


class EmissionFactor(BaseModel):
    """
    Reference table of CO2e conversion factors (kg CO2e per unit of activity),
    e.g. "Electricity (grid, India)" -> 0.82 kgCO2e/kWh.
    organization_id is nullable: null = a global factor available to everyone,
    set = an org-specific override.
    """

    __tablename__ = "emission_factors"

    organization_id = db.Column(
        db.Integer, db.ForeignKey("organizations.id"), nullable=True, index=True
    )
    name = db.Column(db.String(150), nullable=False)
    scope = db.Column(db.String(20), nullable=False, default="scope_1")  # scope_1/2/3
    category = db.Column(db.String(80), nullable=False)  # electricity, fuel, travel, waste...
    unit = db.Column(db.String(30), nullable=False)  # kWh, litre, km, kg...
    factor_value = db.Column(db.Numeric(12, 6), nullable=False)  # kg CO2e per unit
    source = db.Column(db.String(150))  # e.g. "DEFRA 2024", "CEA India"
    is_active = db.Column(db.Boolean, default=True, nullable=False)

    organization = db.relationship("Organization", foreign_keys=[organization_id])

    def __repr__(self):
        return f"<EmissionFactor {self.name} ({self.factor_value} kgCO2e/{self.unit})>"


class CarbonTransaction(BaseModel):
    """
    A single logged activity that produces (or avoids) emissions, e.g.
    "450 kWh of grid electricity used by Operations in March".
    co2e_kg is computed at save time from quantity * emission_factor.factor_value.
    """

    __tablename__ = "carbon_transactions"

    organization_id = db.Column(
        db.Integer, db.ForeignKey("organizations.id"), nullable=False, index=True
    )
    department_id = db.Column(db.Integer, db.ForeignKey("departments.id"), nullable=True, index=True)
    logged_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    emission_factor_id = db.Column(
        db.Integer, db.ForeignKey("emission_factors.id"), nullable=False, index=True
    )

    activity_date = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    quantity = db.Column(db.Numeric(14, 4), nullable=False)
    co2e_kg = db.Column(db.Numeric(16, 4), nullable=False)
    notes = db.Column(db.String(500))

    status = db.Column(db.String(20), nullable=False, default="pending", index=True)
    approved_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    approved_at = db.Column(db.DateTime, nullable=True)
    rejection_reason = db.Column(db.String(300))

    department = db.relationship("Department", foreign_keys=[department_id])
    logged_by = db.relationship("User", foreign_keys=[logged_by_id])
    approved_by = db.relationship("User", foreign_keys=[approved_by_id])
    emission_factor = db.relationship("EmissionFactor", foreign_keys=[emission_factor_id])

    def compute_co2e(self):
        self.co2e_kg = float(self.quantity) * float(self.emission_factor.factor_value)
        return self.co2e_kg

    def approve(self, approver_id):
        self.status = "approved"
        self.approved_by_id = approver_id
        self.approved_at = datetime.utcnow()

    def reject(self, approver_id, reason=None):
        self.status = "rejected"
        self.approved_by_id = approver_id
        self.approved_at = datetime.utcnow()
        self.rejection_reason = reason

    def __repr__(self):
        return f"<CarbonTransaction {self.co2e_kg}kg CO2e ({self.status})>"
