"""
Builds downloadable ESG reports from the aggregated data in
app/utils/analytics.py and app/utils/ai_engine.py:

  - build_pdf_report()    -> PDF with embedded reportlab charts
  - build_excel_report()  -> multi-sheet workbook with embedded openpyxl charts
  - build_csv_export()    -> single-dataset CSV (raw data, no charts)

Every builder takes (organization_id, org_name) rather than an ORM
object so it works for org-scoped users and for super_admins viewing
platform-wide data (organization_id=None).
"""
import csv
import io
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
)
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.charts.linecharts import HorizontalLineChart

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.styles import Font, PatternFill

from app.utils import analytics, ai_engine

BRAND = colors.HexColor("#4f8a6c")
BRAND_DARK = colors.HexColor("#2f5940")
PALETTE = [BRAND, BRAND_DARK, colors.HexColor("#c1483f"), colors.HexColor("#d9a441"), colors.HexColor("#5b7fa6")]


# --------------------------------------------------------------------------
# PDF
# --------------------------------------------------------------------------

def _pdf_styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle(name="ReportTitle", fontSize=22, leading=26, textColor=BRAND_DARK, spaceAfter=6))
    ss.add(ParagraphStyle(name="ReportSubtitle", fontSize=11, textColor=colors.grey, spaceAfter=20))
    ss.add(ParagraphStyle(name="SectionHeading", fontSize=14, textColor=BRAND_DARK, spaceBefore=16, spaceAfter=8))
    return ss


def _monthly_emissions_chart(monthly_series):
    labels = list(monthly_series.keys())
    values = list(monthly_series.values())
    d = Drawing(440, 190)
    chart = HorizontalLineChart()
    chart.x, chart.y = 45, 35
    chart.width, chart.height = 370, 130
    chart.data = [values]
    chart.categoryAxis.categoryNames = labels
    chart.categoryAxis.labels.angle = 30
    chart.categoryAxis.labels.fontSize = 6
    chart.categoryAxis.labels.dy = -10
    chart.valueAxis.valueMin = 0
    chart.lines[0].strokeColor = BRAND
    chart.lines[0].strokeWidth = 2.2
    d.add(chart)
    return d


def _pie_chart(data_dict, width=440, height=190):
    d = Drawing(width, height)
    pie = Pie()
    pie.x, pie.y = 160, 15
    pie.width, pie.height = 150, 150
    pie.data = list(data_dict.values())
    pie.labels = [f"{k} ({v:.0f})" for k, v in data_dict.items()]
    pie.slices.strokeWidth = 0.5
    pie.slices.strokeColor = colors.white
    for i in range(len(pie.data)):
        pie.slices[i].fillColor = PALETTE[i % len(PALETTE)]
    d.add(pie)
    return d


def _bar_chart(data_dict, width=440, height=190):
    labels = list(data_dict.keys())
    values = list(data_dict.values())
    d = Drawing(width, height)
    chart = VerticalBarChart()
    chart.x, chart.y = 45, 35
    chart.width, chart.height = 370, 130
    chart.data = [values]
    chart.categoryAxis.categoryNames = labels
    chart.categoryAxis.labels.angle = 30
    chart.categoryAxis.labels.fontSize = 6
    chart.categoryAxis.labels.dy = -10
    chart.valueAxis.valueMin = 0
    chart.bars[0].fillColor = BRAND
    d.add(chart)
    return d


def build_pdf_report(organization_id, org_name) -> io.BytesIO:
    env = analytics.environmental_summary(organization_id)
    soc = analytics.social_summary(organization_id)
    gov = analytics.governance_summary(organization_id)
    pillars = analytics.pillar_scores(organization_id)
    prediction = ai_engine.predict_esg_score(organization_id)
    recs = ai_engine.generate_recommendations(organization_id)
    anomalies = ai_engine.detect_anomalies(organization_id)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4, topMargin=2 * cm, bottomMargin=2 * cm, leftMargin=2 * cm, rightMargin=2 * cm,
        title=f"{org_name} ESG Sustainability Report",
    )
    styles = _pdf_styles()
    story = []

    story.append(Paragraph(org_name, styles["ReportTitle"]))
    story.append(Paragraph(
        f"ESG Sustainability Report &mdash; Generated {datetime.utcnow().strftime('%d %b %Y')}",
        styles["ReportSubtitle"],
    ))

    kpi_table = Table(
        [
            ["Overall ESG Score", "Environmental", "Social", "Governance"],
            [f"{pillars['overall']}", f"{pillars['environmental']}", f"{pillars['social']}", f"{pillars['governance']}"],
        ],
        colWidths=[4 * cm] * 4,
    )
    kpi_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), BRAND),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 11),
        ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#d8dee2")),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(kpi_table)

    # --- Environmental -----------------------------------------------------
    story.append(Paragraph("Environmental", styles["SectionHeading"]))
    story.append(Paragraph(
        f"Total tracked emissions: <b>{env['total_co2e_kg']:.1f} kg CO2e</b> across "
        f"{env['transaction_count']} approved transactions "
        f"({env['pending_count']} pending, {env['rejected_count']} rejected).",
        styles["BodyText"],
    ))
    if env["monthly_series"]:
        story.append(Spacer(1, 8))
        story.append(_monthly_emissions_chart(env["monthly_series"]))
    if env["by_scope"]:
        story.append(Spacer(1, 4))
        story.append(_pie_chart(env["by_scope"]))

    # --- Social --------------------------------------------------------------
    story.append(PageBreak())
    story.append(Paragraph("Social / CSR", styles["SectionHeading"]))
    story.append(Paragraph(
        f"{len(soc['activities'])} CSR activities &middot; {soc['total_participants']} participants "
        f"&middot; {soc['total_hours']:.1f} volunteer hours logged &middot; "
        f"total budget {soc['total_budget']:.0f}.",
        styles["BodyText"],
    ))
    if soc["by_category"]:
        story.append(Spacer(1, 8))
        story.append(_bar_chart({k: v for k, v in soc["by_category"].items()}))

    # --- Governance ------------------------------------------------------
    story.append(Spacer(1, 14))
    story.append(Paragraph("Governance", styles["SectionHeading"]))
    avg_score_txt = f"{gov['avg_audit_score']:.1f}/100" if gov["avg_audit_score"] is not None else "N/A"
    story.append(Paragraph(
        f"Average audit score: <b>{avg_score_txt}</b> &middot; {gov['open_issue_count']} open "
        f"compliance issue(s), {gov['overdue_issue_count']} overdue.",
        styles["BodyText"],
    ))

    # --- AI insights -------------------------------------------------------
    story.append(PageBreak())
    story.append(Paragraph("AI-Generated Insights", styles["SectionHeading"]))
    story.append(Paragraph(
        f"Predicted ESG score (~{prediction['projection_days']} days ahead): "
        f"<b>{prediction['predicted_score']}</b> ({prediction['trend']}, "
        f"{prediction['confidence']} confidence) &mdash; {prediction['method']}.",
        styles["BodyText"],
    ))
    story.append(Spacer(1, 8))
    story.append(Paragraph(f"<b>Anomalies detected: {len(anomalies)}</b>", styles["BodyText"]))
    for a in anomalies[:8]:
        t = a["transaction"]
        story.append(Paragraph(
            f"&bull; {t.activity_date.strftime('%d %b %Y')} &mdash; {a['co2e_kg']:.1f} kg CO2e "
            f"({a['reason']}, z={a['z_score']})",
            styles["BodyText"],
        ))
    story.append(Spacer(1, 8))
    story.append(Paragraph("<b>Recommendations</b>", styles["BodyText"]))
    for r in recs:
        story.append(Paragraph(f"&bull; [{r['priority'].upper()}] {r['title']} &mdash; {r['detail']}", styles["BodyText"]))

    doc.build(story)
    buf.seek(0)
    return buf


# --------------------------------------------------------------------------
# Excel
# --------------------------------------------------------------------------

def build_excel_report(organization_id, org_name) -> io.BytesIO:
    env = analytics.environmental_summary(organization_id)
    soc = analytics.social_summary(organization_id)
    gov = analytics.governance_summary(organization_id)
    pillars = analytics.pillar_scores(organization_id)
    prediction = ai_engine.predict_esg_score(organization_id)
    recs = ai_engine.generate_recommendations(organization_id)

    header_fill = PatternFill("solid", fgColor="4F8A6C")
    header_font = Font(color="FFFFFF", bold=True)

    def style_header(ws, row):
        for cell in ws[row]:
            cell.font = header_font
            cell.fill = header_fill

    def autosize(ws):
        for col in ws.columns:
            length = max((len(str(c.value)) for c in col if c.value is not None), default=10)
            ws.column_dimensions[col[0].column_letter].width = min(60, max(12, length + 2))

    wb = Workbook()

    # --- Summary sheet -----------------------------------------------------
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = f"{org_name} \u2014 ESG Sustainability Report"
    ws["A1"].font = Font(size=15, bold=True, color="2F5940")
    ws["A2"] = f"Generated {datetime.utcnow().strftime('%d %b %Y')}"
    ws.append([])
    ws.append(["Pillar", "Score"])
    style_header(ws, 4)
    ws.append(["Overall", pillars["overall"]])
    ws.append(["Environmental", pillars["environmental"]])
    ws.append(["Social", pillars["social"]])
    ws.append(["Governance", pillars["governance"]])
    ws.append([])
    ws.append(["Predicted next-period score", prediction["predicted_score"]])
    ws.append(["Trend", prediction["trend"]])
    ws.append(["Confidence", prediction["confidence"]])

    pie = PieChart()
    pie.title = "ESG Pillar Scores"
    pie.add_data(Reference(ws, min_col=2, min_row=4, max_row=8), titles_from_data=True)
    pie.set_categories(Reference(ws, min_col=1, min_row=5, max_row=8))
    ws.add_chart(pie, "E4")
    autosize(ws)

    # --- Environmental sheet -------------------------------------------
    ws2 = wb.create_sheet("Environmental")
    ws2.append(["Month", "CO2e (kg)"])
    style_header(ws2, 1)
    for month, val in env["monthly_series"].items():
        ws2.append([month, round(val, 2)])
    if env["monthly_series"]:
        n = len(env["monthly_series"])
        chart = LineChart()
        chart.title = "Monthly CO2e Emissions"
        chart.add_data(Reference(ws2, min_col=2, min_row=1, max_row=n + 1), titles_from_data=True)
        chart.set_categories(Reference(ws2, min_col=1, min_row=2, max_row=n + 1))
        ws2.add_chart(chart, "D2")

    cat_start = ws2.max_row + 3
    ws2.cell(row=cat_start, column=1, value="Category")
    ws2.cell(row=cat_start, column=2, value="CO2e (kg)")
    style_header(ws2, cat_start)
    for i, (cat, val) in enumerate(env["by_category"].items(), start=1):
        ws2.cell(row=cat_start + i, column=1, value=cat)
        ws2.cell(row=cat_start + i, column=2, value=round(val, 2))
    if env["by_category"]:
        n = len(env["by_category"])
        bar = BarChart()
        bar.title = "Emissions by Category"
        bar.add_data(Reference(ws2, min_col=2, min_row=cat_start, max_row=cat_start + n), titles_from_data=True)
        bar.set_categories(Reference(ws2, min_col=1, min_row=cat_start + 1, max_row=cat_start + n))
        ws2.add_chart(bar, f"D{cat_start}")
    autosize(ws2)

    # --- Raw carbon transactions -----------------------------------------
    ws3 = wb.create_sheet("Carbon Transactions")
    ws3.append(["Date", "Department", "Factor", "Scope", "Quantity", "Unit", "CO2e (kg)", "Status", "Logged By"])
    style_header(ws3, 1)
    for t in env["transactions"]:
        ws3.append([
            t.activity_date.isoformat(),
            t.department.name if t.department else "",
            t.emission_factor.name if t.emission_factor else "",
            t.emission_factor.scope if t.emission_factor else "",
            float(t.quantity),
            t.emission_factor.unit if t.emission_factor else "",
            float(t.co2e_kg),
            t.status,
            t.logged_by.full_name if t.logged_by else "",
        ])
    autosize(ws3)

    # --- Social sheet -----------------------------------------------------
    ws4 = wb.create_sheet("Social - CSR")
    ws4.append(["Title", "Category", "Status", "Date", "Budget", "Participants", "Hours"])
    style_header(ws4, 1)
    for a in soc["activities"]:
        ws4.append([a.title, a.category, a.status, a.activity_date.isoformat(),
                    float(a.budget or 0), a.participant_count, float(a.total_hours)])
    autosize(ws4)

    # --- Governance sheet ---------------------------------------------------
    ws5 = wb.create_sheet("Governance")
    ws5.append(["Audit Title", "Type", "Status", "Scheduled", "Score"])
    style_header(ws5, 1)
    for a in gov["audits"]:
        ws5.append([a.title, a.audit_type, a.status, a.scheduled_date.isoformat(),
                    float(a.score) if a.score is not None else None])
    issue_header_row = ws5.max_row + 2
    ws5.cell(row=issue_header_row, column=1, value="Compliance Issue")
    ws5.cell(row=issue_header_row, column=2, value="Severity")
    ws5.cell(row=issue_header_row, column=3, value="Status")
    ws5.cell(row=issue_header_row, column=4, value="Due Date")
    style_header(ws5, issue_header_row)
    for i in gov["issues"]:
        ws5.append([i.title, i.severity, i.status, i.due_date.isoformat() if i.due_date else ""])
    autosize(ws5)

    # --- AI recommendations ----------------------------------------------
    ws6 = wb.create_sheet("AI Recommendations")
    ws6.append(["Priority", "Module", "Title", "Detail"])
    style_header(ws6, 1)
    for r in recs:
        ws6.append([r["priority"], r["module"], r["title"], r["detail"]])
    autosize(ws6)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


# --------------------------------------------------------------------------
# CSV
# --------------------------------------------------------------------------

def build_csv_export(fieldnames, rows) -> io.BytesIO:
    text_buf = io.StringIO()
    writer = csv.writer(text_buf)
    writer.writerow(fieldnames)
    writer.writerows(rows)
    out = io.BytesIO(text_buf.getvalue().encode("utf-8"))
    out.seek(0)
    return out


def transactions_csv_dataset(organization_id):
    env = analytics.environmental_summary(organization_id)
    fieldnames = ["Date", "Department", "Factor", "Scope", "Category", "Quantity", "Unit", "CO2e_kg", "Status", "Logged By"]
    rows = [
        [
            t.activity_date.isoformat(),
            t.department.name if t.department else "",
            t.emission_factor.name if t.emission_factor else "",
            t.emission_factor.scope if t.emission_factor else "",
            t.emission_factor.category if t.emission_factor else "",
            float(t.quantity),
            t.emission_factor.unit if t.emission_factor else "",
            float(t.co2e_kg),
            t.status,
            t.logged_by.full_name if t.logged_by else "",
        ]
        for t in env["transactions"]
    ]
    return fieldnames, rows


def csr_csv_dataset(organization_id):
    soc = analytics.social_summary(organization_id)
    fieldnames = ["Title", "Category", "Status", "Date", "Budget", "Beneficiaries Target", "Participants", "Hours"]
    rows = [
        [a.title, a.category, a.status, a.activity_date.isoformat(), float(a.budget or 0),
         a.beneficiaries_target or 0, a.participant_count, float(a.total_hours)]
        for a in soc["activities"]
    ]
    return fieldnames, rows


def audits_csv_dataset(organization_id):
    gov = analytics.governance_summary(organization_id)
    fieldnames = ["Title", "Type", "Status", "Scheduled", "Completed", "Score", "Findings"]
    rows = [
        [a.title, a.audit_type, a.status, a.scheduled_date.isoformat(),
         a.completed_date.isoformat() if a.completed_date else "",
         float(a.score) if a.score is not None else "", a.findings_summary or ""]
        for a in gov["audits"]
    ]
    return fieldnames, rows


def issues_csv_dataset(organization_id):
    gov = analytics.governance_summary(organization_id)
    fieldnames = ["Title", "Category", "Severity", "Status", "Due Date", "Assigned To"]
    rows = [
        [i.title, i.category or "", i.severity, i.status,
         i.due_date.isoformat() if i.due_date else "",
         i.assigned_to.full_name if i.assigned_to else ""]
        for i in gov["issues"]
    ]
    return fieldnames, rows
