"""
Read-only, org-scoped aggregation helpers shared by the Reports module
and the AI Insights engine (app/utils/ai_engine.py). Nothing here writes
to the database — it only shapes query results into summaries that are
cheap to re-run on demand (no caching table needed at this data volume).
"""
from datetime import date
from collections import defaultdict

from app.models.environmental import CarbonTransaction
from app.models.social import CSRActivity
from app.models.governance import Audit, ComplianceIssue


def _scope(query, model, organization_id):
    if organization_id:
        return query.filter(model.organization_id == organization_id)
    return query


def environmental_summary(organization_id):
    q = _scope(CarbonTransaction.query.filter_by(is_deleted=False), CarbonTransaction, organization_id)
    approved = q.filter_by(status="approved").order_by(CarbonTransaction.activity_date).all()
    pending_count = q.filter_by(status="pending").count()
    rejected_count = q.filter_by(status="rejected").count()

    total_co2e = sum(float(t.co2e_kg) for t in approved)

    by_scope = defaultdict(float)
    by_category = defaultdict(float)
    monthly = defaultdict(float)
    for t in approved:
        factor = t.emission_factor
        by_scope[factor.scope if factor else "unknown"] += float(t.co2e_kg)
        by_category[factor.category if factor else "unknown"] += float(t.co2e_kg)
        monthly[t.activity_date.strftime("%Y-%m")] += float(t.co2e_kg)

    return {
        "total_co2e_kg": total_co2e,
        "transaction_count": len(approved),
        "pending_count": pending_count,
        "rejected_count": rejected_count,
        "by_scope": dict(sorted(by_scope.items())),
        "by_category": dict(sorted(by_category.items(), key=lambda kv: -kv[1])),
        "monthly_series": dict(sorted(monthly.items())),
        "transactions": approved,
    }


def social_summary(organization_id):
    q = _scope(CSRActivity.query.filter_by(is_deleted=False), CSRActivity, organization_id)
    activities = q.order_by(CSRActivity.activity_date).all()

    by_category = defaultdict(int)
    by_status = defaultdict(int)
    total_participants = 0
    total_hours = 0.0
    for a in activities:
        by_category[a.category] += 1
        by_status[a.status] += 1
        total_participants += a.participant_count
        total_hours += a.total_hours

    return {
        "activities": activities,
        "total_budget": sum(float(a.budget or 0) for a in activities),
        "total_beneficiaries_target": sum(a.beneficiaries_target or 0 for a in activities),
        "total_participants": total_participants,
        "total_hours": total_hours,
        "by_category": dict(by_category),
        "by_status": dict(by_status),
    }


def governance_summary(organization_id):
    aq = _scope(Audit.query.filter_by(is_deleted=False), Audit, organization_id)
    audits = aq.order_by(Audit.scheduled_date).all()
    completed_audits = [a for a in audits if a.status == "completed" and a.score is not None]
    avg_audit_score = (
        sum(float(a.score) for a in completed_audits) / len(completed_audits)
        if completed_audits else None
    )

    iq = _scope(ComplianceIssue.query.filter_by(is_deleted=False), ComplianceIssue, organization_id)
    issues = iq.order_by(ComplianceIssue.due_date).all()
    open_issues = [i for i in issues if i.status in ("open", "in_progress")]
    overdue_issues = [i for i in open_issues if i.due_date and i.due_date < date.today()]

    by_severity = defaultdict(int)
    for i in open_issues:
        by_severity[i.severity] += 1

    return {
        "audits": audits,
        "completed_audits": completed_audits,
        "avg_audit_score": avg_audit_score,
        "issues": issues,
        "open_issue_count": len(open_issues),
        "overdue_issue_count": len(overdue_issues),
        "by_severity": dict(by_severity),
    }


def pillar_scores(organization_id):
    """
    Heuristic 0-100 composite scores per ESG pillar, blended into an
    overall score (Environmental 40% / Social 30% / Governance 30%).
    These are transparent, explainable rules rather than a black-box
    model — the weights and thresholds below are the whole "formula".
    """
    env = environmental_summary(organization_id)
    soc = social_summary(organization_id)
    gov = governance_summary(organization_id)

    # Environmental: rewards a falling emissions trend and a healthy
    # approved/pending/rejected ratio.
    env_score = 70.0
    values = list(env["monthly_series"].values())
    if len(values) >= 2 and (max(values) - min(values)) > 0:
        span = max(values) - min(values)
        delta = values[-1] - values[0]
        env_score += max(-25.0, min(25.0, -delta / span * 25.0))
    total_txn = env["transaction_count"] + env["pending_count"] + env["rejected_count"]
    if total_txn:
        clean_ratio = env["transaction_count"] / total_txn
        env_score += (clean_ratio - 0.7) * 30.0
    env_score = max(0.0, min(100.0, env_score))

    # Social: rewards completed activities and healthy participation.
    soc_score = 60.0
    activities = soc["activities"]
    if activities:
        completed_ratio = soc["by_status"].get("completed", 0) / len(activities)
        avg_participants = soc["total_participants"] / len(activities)
        soc_score = 50.0 + completed_ratio * 25.0 + min(25.0, avg_participants * 2.5)
    soc_score = max(0.0, min(100.0, soc_score))

    # Governance: audit scores minus a penalty for open/overdue issues.
    gov_score = gov["avg_audit_score"] if gov["avg_audit_score"] is not None else 65.0
    gov_score -= gov["open_issue_count"] * 3.0
    gov_score -= gov["overdue_issue_count"] * 5.0
    gov_score = max(0.0, min(100.0, gov_score))

    overall = round(env_score * 0.4 + soc_score * 0.3 + gov_score * 0.3, 1)

    return {
        "environmental": round(env_score, 1),
        "social": round(soc_score, 1),
        "governance": round(gov_score, 1),
        "overall": overall,
    }
