"""
Lightweight, self-contained "AI" features for EcoSphere:

  - ESG score prediction  : linear-trend regression over an org's audit
                             score history (numpy.polyfit), projecting
                             ~90 days ahead, with a confidence label
                             derived from the fit's R^2.
  - Anomaly detection      : per-emission-factor IQR / z-score outlier
                             detection over approved carbon transactions.
  - Recommendation engine  : transparent, rule-based checks over the
                             same aggregated data used by the reports.

Deliberately dependency-light (numpy only) and fully explainable — every
number produced here can be traced back to a plain statistical rule
rather than an opaque model, which matters for an ESG compliance tool.
"""
from collections import defaultdict

import numpy as np

from app.utils import analytics

PROJECTION_DAYS = 90


def predict_esg_score(organization_id):
    gov = analytics.governance_summary(organization_id)
    pillars = analytics.pillar_scores(organization_id)

    completed = sorted(
        [a for a in gov["completed_audits"] if a.completed_date],
        key=lambda a: a.completed_date,
    )

    if len(completed) >= 2:
        x = np.array([(a.completed_date - completed[0].completed_date).days for a in completed], dtype=float)
        y = np.array([float(a.score) for a in completed], dtype=float)
        slope, intercept = np.polyfit(x, y, 1)

        predicted = slope * (x[-1] + PROJECTION_DAYS) + intercept
        predicted = float(max(0.0, min(100.0, predicted)))

        y_pred = slope * x + intercept
        ss_res = float(np.sum((y - y_pred) ** 2))
        ss_tot = float(np.sum((y - y.mean()) ** 2))
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0

        confidence = "high" if r2 > 0.6 else "medium" if r2 > 0.25 else "low"
        trend = "improving" if slope > 0.02 else "declining" if slope < -0.02 else "stable"
        method = f"linear regression on {len(completed)} completed audit scores (R\u00b2={r2:.2f})"
    else:
        predicted = pillars["overall"]
        confidence = "low"
        trend = "stable"
        method = "baseline composite score — need at least 2 completed audits for a trend model"

    return {
        "current_score": pillars["overall"],
        "predicted_score": round(predicted, 1),
        "trend": trend,
        "confidence": confidence,
        "method": method,
        "projection_days": PROJECTION_DAYS,
        "history": [
            {"date": a.completed_date.isoformat(), "score": float(a.score)} for a in completed
        ],
        "pillars": pillars,
    }


def detect_anomalies(organization_id):
    env = analytics.environmental_summary(organization_id)

    by_factor = defaultdict(list)
    for t in env["transactions"]:
        by_factor[t.emission_factor_id].append(t)

    anomalies = []
    for group in by_factor.values():
        if len(group) < 4:
            continue  # not enough history for this factor to judge statistically
        values = np.array([float(t.co2e_kg) for t in group])
        q1, q3 = np.percentile(values, [25, 75])
        iqr = q3 - q1
        lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        mean, std = values.mean(), (values.std() or 1.0)

        for t in group:
            v = float(t.co2e_kg)
            if v < lower or v > upper:
                z = (v - mean) / std
                anomalies.append({
                    "transaction": t,
                    "co2e_kg": v,
                    "expected_range": (round(float(lower), 2), round(float(upper), 2)),
                    "z_score": round(float(z), 2),
                    "severity": "high" if abs(z) > 3 else "medium",
                    "reason": (
                        f"{'Unusually high' if v > upper else 'Unusually low'} vs. "
                        f"{t.emission_factor.name if t.emission_factor else 'this factor'} history"
                    ),
                })

    anomalies.sort(key=lambda a: -abs(a["z_score"]))
    return anomalies


def generate_recommendations(organization_id):
    env = analytics.environmental_summary(organization_id)
    soc = analytics.social_summary(organization_id)
    gov = analytics.governance_summary(organization_id)

    recs = []

    if env["by_category"] and env["total_co2e_kg"] > 0:
        top_cat, top_val = next(iter(env["by_category"].items()))
        share = top_val / env["total_co2e_kg"]
        if share > 0.4:
            recs.append({
                "module": "environmental", "priority": "high",
                "title": f"Reduce reliance on {top_cat}",
                "detail": (
                    f"{top_cat} accounts for {share * 100:.0f}% of tracked emissions "
                    f"({top_val:.0f} kg CO2e). Consider efficiency upgrades or a "
                    "lower-carbon alternative for this category."
                ),
            })

    if env["pending_count"] > 5:
        recs.append({
            "module": "environmental", "priority": "medium",
            "title": "Clear the carbon approval backlog",
            "detail": (
                f"{env['pending_count']} transactions are awaiting approval, which "
                "delays accurate emissions reporting."
            ),
        })

    if soc["activities"]:
        avg_participants = soc["total_participants"] / len(soc["activities"])
        if avg_participants < 5:
            recs.append({
                "module": "social", "priority": "medium",
                "title": "Boost CSR participation",
                "detail": (
                    f"Average participation is only {avg_participants:.1f} employees per "
                    "activity. Promote upcoming activities more widely or lower the "
                    "sign-up barrier."
                ),
            })

    if gov["overdue_issue_count"] > 0:
        recs.append({
            "module": "governance", "priority": "high",
            "title": "Resolve overdue compliance issues",
            "detail": (
                f"{gov['overdue_issue_count']} compliance issue(s) are past their due "
                "date and need immediate attention."
            ),
        })

    if gov["avg_audit_score"] is not None and gov["avg_audit_score"] < 70:
        recs.append({
            "module": "governance", "priority": "high",
            "title": "Address recurring audit gaps",
            "detail": (
                f"Average audit score is {gov['avg_audit_score']:.1f}/100. Review "
                "recent findings for systemic root causes rather than one-off fixes."
            ),
        })

    if not recs:
        recs.append({
            "module": "general", "priority": "low",
            "title": "You're on track",
            "detail": (
                "No urgent risk signals in current ESG data. Keep logging activity "
                "to improve prediction accuracy over time."
            ),
        })

    order = {"high": 0, "medium": 1, "low": 2}
    recs.sort(key=lambda r: order.get(r["priority"], 3))
    return recs
