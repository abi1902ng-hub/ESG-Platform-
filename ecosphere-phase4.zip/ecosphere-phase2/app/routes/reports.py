from datetime import datetime

from flask import Blueprint, render_template, send_file, request, abort
from flask_login import login_required, current_user

from app.extensions import db
from app.models.audit import ActivityLog
from app.utils.rbac import permission_required
from app.utils import analytics, ai_engine, report_generator as rg

reports_bp = Blueprint("reports", __name__, template_folder="../templates/reports")

DATASETS = {
    "transactions": ("Carbon Transactions", rg.transactions_csv_dataset),
    "csr": ("CSR Activities", rg.csr_csv_dataset),
    "audits": ("Audits", rg.audits_csv_dataset),
    "issues": ("Compliance Issues", rg.issues_csv_dataset),
}


def _org_id():
    return current_user.organization_id


def _org_name():
    org = current_user.organization
    return org.name if org else "EcoSphere Platform (All Organizations)"


def _log(action, description):
    ActivityLog.log(
        action=action, user_id=current_user.id, organization_id=current_user.organization_id,
        module="reports", description=description,
        ip_address=request.remote_addr, user_agent=str(request.user_agent),
    )
    db.session.commit()


@reports_bp.route("/")
@login_required
@permission_required("report.view")
def index():
    org_id = _org_id()
    pillars = analytics.pillar_scores(org_id)
    prediction = ai_engine.predict_esg_score(org_id)
    recommendations = ai_engine.generate_recommendations(org_id)
    anomalies = ai_engine.detect_anomalies(org_id)
    return render_template(
        "reports/index.html",
        pillars=pillars, prediction=prediction,
        recommendations=recommendations[:3], anomaly_count=len(anomalies),
    )


@reports_bp.route("/ai-insights")
@login_required
@permission_required("report.view")
def ai_insights():
    org_id = _org_id()
    prediction = ai_engine.predict_esg_score(org_id)
    recommendations = ai_engine.generate_recommendations(org_id)
    anomalies = ai_engine.detect_anomalies(org_id)
    return render_template(
        "reports/ai_insights.html",
        prediction=prediction, recommendations=recommendations, anomalies=anomalies,
    )


@reports_bp.route("/pdf")
@login_required
@permission_required("report.export")
def export_pdf():
    buf = rg.build_pdf_report(_org_id(), _org_name())
    _log("report.export", "Exported PDF ESG sustainability report")
    filename = f"ecosphere-esg-report-{datetime.utcnow().strftime('%Y%m%d')}.pdf"
    return send_file(buf, mimetype="application/pdf", as_attachment=True, download_name=filename)


@reports_bp.route("/excel")
@login_required
@permission_required("report.export")
def export_excel():
    buf = rg.build_excel_report(_org_id(), _org_name())
    _log("report.export", "Exported Excel ESG report")
    filename = f"ecosphere-esg-report-{datetime.utcnow().strftime('%Y%m%d')}.xlsx"
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True, download_name=filename,
    )


@reports_bp.route("/csv/<dataset>")
@login_required
@permission_required("report.export")
def export_csv(dataset):
    if dataset not in DATASETS:
        abort(404)
    label, fetch = DATASETS[dataset]
    fieldnames, rows = fetch(_org_id())
    buf = rg.build_csv_export(fieldnames, rows)
    _log("report.export", f"Exported CSV: {label}")
    filename = f"ecosphere-{dataset}-{datetime.utcnow().strftime('%Y%m%d')}.csv"
    return send_file(buf, mimetype="text/csv", as_attachment=True, download_name=filename)
